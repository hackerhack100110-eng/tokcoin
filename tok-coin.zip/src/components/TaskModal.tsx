import React, { useState, useEffect, useRef } from 'react';
import { TaskItem, VipLevel } from '../types';
import { formatCOP } from '../config/vipConfig';
import { X, Play, Pause, Heart, Share2, CheckCircle2, ShieldCheck, Flame, AlertCircle, Youtube } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TaskModalProps {
  task: TaskItem;
  vip: VipLevel;
  onClose: () => void;
  onClaim: (task: TaskItem) => { success: boolean; reward: number; message: string };
}

export const TaskModal: React.FC<TaskModalProps> = ({ task, vip, onClose, onClaim }) => {
  const [secondsRemaining, setSecondsRemaining] = useState(task.durationSeconds || 8);
  const [isPlaying, setIsPlaying] = useState(true);
  const [hasLiked, setHasLiked] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [claimedReward, setClaimedReward] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Timer countdown
  useEffect(() => {
    if (secondsRemaining <= 0) return;
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [secondsRemaining]);

  const canClaim = secondsRemaining === 0 && !isCompleted;

  const handleClaim = () => {
    if (!canClaim) return;
    const res = onClaim(task);
    if (res.success) {
      setIsCompleted(true);
      setClaimedReward(res.reward);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#ef4444', '#f59e0b', '#ffffff'],
        });
      } catch (e) {
        console.error('Confetti err', e);
      }
    } else {
      setErrorMsg(res.message);
    }
  };

  const toggleVideo = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const hasYoutube = Boolean(task.youtubeId);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="relative w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800/80 bg-zinc-900/80">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
              {hasYoutube && <Youtube className="w-4 h-4 text-red-500" />}
              {task.platform} • Tarea Oficial
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Section: Real YouTube Embed or Local Video with fallback visualizer */}
        <div className="relative bg-zinc-950 aspect-[9/13] max-h-[380px] w-full flex items-center justify-center overflow-hidden">
          {hasYoutube ? (
            /* YouTube IFrame Player */
            <div className="relative w-full h-full bg-black">
              <iframe
                title={task.title}
                src={`https://www.youtube-nocookie.com/embed/${task.youtubeId}?autoplay=1&mute=1&playsinline=1&controls=1&rel=0&modestbranding=1&loop=1&playlist=${task.youtubeId}`}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
          ) : (
            /* Native Video / Visual Stream */
            <div className="relative w-full h-full">
              <div className="absolute inset-0 overflow-hidden">
                <img
                  src={task.thumbnail}
                  alt={task.title}
                  className={`w-full h-full object-cover transition-transform duration-1000 ${
                    isPlaying ? 'scale-105' : 'scale-100'
                  }`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/60" />

                {/* Simulated Live Equalizer Waveform */}
                <div className="absolute bottom-20 left-4 right-4 flex items-end gap-1.5 h-12 opacity-80 pointer-events-none">
                  {[40, 75, 55, 90, 60, 85, 30, 95, 65, 50, 80, 45, 90, 70, 60, 85, 40].map((h, i) => (
                    <div
                      key={i}
                      className="flex-1 bg-gradient-to-t from-rose-500 to-amber-400 rounded-full transition-all duration-300"
                      style={{
                        height: isPlaying ? `${(h * ((i % 3) + 1)) % 100}%` : '20%',
                        opacity: isPlaying ? 0.85 : 0.3,
                      }}
                    />
                  ))}
                </div>
              </div>

              {task.videoUrl && (
                <video
                  ref={videoRef}
                  src={task.videoUrl}
                  poster={task.thumbnail}
                  autoPlay
                  playsInline
                  muted
                  loop
                  onLoadedData={() => setVideoLoaded(true)}
                  onError={() => setVideoError(true)}
                  className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 z-10 ${
                    videoLoaded && !videoError ? 'opacity-100' : 'opacity-0'
                  }`}
                />
              )}
            </div>
          )}

          {/* Floating Controls Overlay */}
          <div className="absolute inset-0 z-20 pointer-events-none flex flex-col justify-between p-3">
            {/* Top Right: Countdown Timer */}
            <div className="self-end pointer-events-auto">
              <div className="px-3 py-1.5 rounded-full bg-black/85 backdrop-blur-md border border-rose-500/50 text-xs font-bold text-rose-400 flex items-center gap-1.5 shadow-2xl">
                <Flame className="w-4 h-4 text-rose-500" />
                {secondsRemaining > 0 ? (
                  <span>Mira {secondsRemaining}s para reclamar</span>
                ) : (
                  <span className="text-emerald-400">¡Video verificado!</span>
                )}
              </div>
            </div>

            {/* Bottom Info & Social Simulation */}
            <div className="pointer-events-auto flex items-end justify-between bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2 rounded-xl">
              <div className="max-w-[75%] space-y-1">
                <p className="text-xs font-semibold text-rose-400 flex items-center gap-1">
                  <span>{task.creator}</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] bg-rose-950 text-rose-300 font-bold border border-rose-800">
                    OFICIAL
                  </span>
                </p>
                <p className="text-xs sm:text-sm font-bold text-white line-clamp-1 leading-snug drop-shadow-md">
                  {task.title}
                </p>
                <p className="text-[11px] text-zinc-300">
                  Recompensa:{' '}
                  <span className="text-emerald-400 font-bold font-mono">
                    +{formatCOP(vip.rewardPerTask)} COP
                  </span>
                </p>
              </div>

              {/* Like action */}
              <div className="flex flex-col gap-2 items-center">
                <button
                  onClick={() => setHasLiked(!hasLiked)}
                  className={`p-2 rounded-full transition-all cursor-pointer shadow-lg ${
                    hasLiked ? 'bg-rose-600 text-white scale-110' : 'bg-black/70 text-white hover:bg-black/90'
                  }`}
                  title="Dar Like"
                >
                  <Heart className={`w-4 h-4 ${hasLiked ? 'fill-white' : ''}`} />
                </button>
                {!hasYoutube && (
                  <button
                    onClick={toggleVideo}
                    className="p-2 rounded-full bg-black/70 text-white hover:bg-black/90 transition-colors cursor-pointer shadow-lg"
                    title="Pausar / Reproducir"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Action & Verification Box */}
        <div className="p-4 bg-zinc-950 space-y-3">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {isCompleted ? (
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
              <h4 className="text-base font-bold text-white">¡Recompensa Acreditada!</h4>
              <p className="text-xs text-zinc-300">
                Has recibido <strong className="text-emerald-400 font-mono">+{formatCOP(claimedReward || vip.rewardPerTask)} COP</strong> en tu saldo de TOK COIN.
              </p>
              <button
                onClick={onClose}
                className="mt-2 w-full py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                Volver a la lista de tareas
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> Validación de fuente autorizada
                </span>
                <span className="font-mono text-zinc-300">Nivel {vip.name}</span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-zinc-900 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-rose-500 h-full transition-all duration-300"
                  style={{
                    width: `${Math.min(
                      100,
                      ((task.durationSeconds - secondsRemaining) / task.durationSeconds) * 100
                    )}%`,
                  }}
                />
              </div>

              <button
                disabled={!canClaim}
                onClick={handleClaim}
                className={`w-full py-3 rounded-xl font-bold text-xs sm:text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer ${
                  canClaim
                    ? 'tok-gradient-red text-white hover:opacity-95 tok-glow-red scale-[1.01]'
                    : 'bg-zinc-900 text-zinc-500 border border-zinc-800 cursor-not-allowed opacity-60'
                }`}
              >
                {canClaim ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    Reclamar Recompensa (+{formatCOP(vip.rewardPerTask)} COP)
                  </>
                ) : (
                  <>Mira el video ({secondsRemaining}s restantes)...</>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
