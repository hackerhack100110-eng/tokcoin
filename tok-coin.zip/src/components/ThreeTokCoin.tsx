import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Sparkles, Eye, Maximize2, RotateCcw, Sliders, ChevronDown, ChevronUp } from 'lucide-react';

// Scratch objects outside render loop to prevent garbage collection
const _vec3 = new THREE.Vector3();

interface ThreeTokCoinProps {
  className?: string;
  interactiveMode?: boolean;
}

export const ThreeTokCoin: React.FC<ThreeTokCoinProps> = ({
  className = '',
  interactiveMode = true,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [activeFinish, setActiveFinish] = useState<'rubyGold' | 'cyberObsidian' | 'platinum'>('rubyGold');
  const [isExploded, setIsExploded] = useState(false);
  const [isRotating, setIsRotating] = useState(true);
  const [controlsCollapsed, setControlsCollapsed] = useState(false);
  const [userIsInteracting, setUserIsInteracting] = useState(false);

  // References to communicate with Three.js scene without re-mounting
  const sceneStateRef = useRef({
    finish: 'rubyGold',
    exploded: 0,
    targetExploded: 0,
    rotating: true,
    userRotationX: 0,
    userRotationY: 0,
    targetRotationX: 0.15,
    targetRotationY: 0,
    isPointerDown: false,
    pointerStartX: 0,
    pointerStartY: 0,
  });

  useEffect(() => {
    sceneStateRef.current.finish = activeFinish;
  }, [activeFinish]);

  useEffect(() => {
    sceneStateRef.current.targetExploded = isExploded ? 1 : 0;
  }, [isExploded]);

  useEffect(() => {
    sceneStateRef.current.rotating = isRotating;
  }, [isRotating]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL from GPU renderer info
    const isSoftwareGl = (() => {
      try {
        const testCanvas = document.createElement('canvas');
        const gl = testCanvas.getContext('webgl2') || testCanvas.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x060608, 0.14);

    // Camera
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 350;
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.4, 4.4);

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: true,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);

    // Studio Environment map via PMREMGenerator & RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio 3-Point Lighting Rig
    // 1. Warm Key Light
    const keyLight = new THREE.DirectionalLight(0xfff3e8, 2.4);
    keyLight.position.set(3, 4, 3.5);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0004;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    // 2. Cool Fill Light
    const fillLight = new THREE.HemisphereLight(0x384a60, 0x08080e, 1.4);
    scene.add(fillLight);

    // 3. Ruby Red Rim Light (Accents the TOK COIN edge)
    const rimLight = new THREE.DirectionalLight(0xe11d48, 2.8);
    rimLight.position.set(-3.5, 2.5, -2.5);
    scene.add(rimLight);

    // Procedural Materials
    const goldMaterial = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.92,
      roughness: 0.18,
    });

    const rubyMetallicMaterial = new THREE.MeshStandardMaterial({
      color: 0xbe123c,
      metalness: 0.85,
      roughness: 0.22,
      emissive: 0x4c0519,
      emissiveIntensity: 0.35,
    });

    const darkTitaniumMaterial = new THREE.MeshStandardMaterial({
      color: 0x1f2937,
      metalness: 0.95,
      roughness: 0.28,
    });

    const pureSilverMaterial = new THREE.MeshStandardMaterial({
      color: 0xf3f4f6,
      metalness: 0.98,
      roughness: 0.14,
    });

    const neonRedAccentMaterial = new THREE.MeshStandardMaterial({
      color: 0xff1744,
      metalness: 0.3,
      roughness: 0.2,
      emissive: 0xff1744,
      emissiveIntensity: 0.85,
    });

    // Helper to update finishes
    function applyFinish(type: string) {
      if (type === 'rubyGold') {
        coinBodyMesh.material = goldMaterial;
        coinRimMesh.material = goldMaterial;
        frontEmblemMesh.material = rubyMetallicMaterial;
        backStarMesh.material = rubyMetallicMaterial;
        orbitRing1.material = rubyMetallicMaterial;
        orbitRing2.material = darkTitaniumMaterial;
      } else if (type === 'cyberObsidian') {
        coinBodyMesh.material = darkTitaniumMaterial;
        coinRimMesh.material = darkTitaniumMaterial;
        frontEmblemMesh.material = neonRedAccentMaterial;
        backStarMesh.material = neonRedAccentMaterial;
        orbitRing1.material = neonRedAccentMaterial;
        orbitRing2.material = darkTitaniumMaterial;
      } else {
        // platinum
        coinBodyMesh.material = pureSilverMaterial;
        coinRimMesh.material = pureSilverMaterial;
        frontEmblemMesh.material = rubyMetallicMaterial;
        backStarMesh.material = pureSilverMaterial;
        orbitRing1.material = rubyMetallicMaterial;
        orbitRing2.material = pureSilverMaterial;
      }
    }

    // MAIN COMPOSITE 3D MODEL: Procedural TOK COIN
    const coinMasterGroup = new THREE.Group();
    scene.add(coinMasterGroup);

    // 1. Core Coin Cylinder
    const coinBodyGeo = new THREE.CylinderGeometry(1.2, 1.2, 0.18, 64);
    const coinBodyMesh = new THREE.Mesh(coinBodyGeo, goldMaterial);
    coinBodyMesh.rotation.x = Math.PI / 2;
    coinBodyMesh.castShadow = !isSoftwareGl;
    coinBodyMesh.receiveShadow = !isSoftwareGl;
    coinMasterGroup.add(coinBodyMesh);

    // 2. Outer Coin Rim with Bevel / Milled Edge
    const coinRimGeo = new THREE.TorusGeometry(1.24, 0.08, 24, 72);
    const coinRimMesh = new THREE.Mesh(coinRimGeo, goldMaterial);
    coinMasterGroup.add(coinRimMesh);

    // 3. Procedural Raised "TOK" Logo Front Emblem (Group of beveled box/cylinder bars)
    const frontEmblemGroup = new THREE.Group();
    frontEmblemGroup.position.set(0, 0, 0.11);

    // Letter T
    const tTopGeo = new THREE.BoxGeometry(0.5, 0.1, 0.06);
    const tTop = new THREE.Mesh(tTopGeo, rubyMetallicMaterial);
    tTop.position.set(-0.55, 0.28, 0);
    const tStemGeo = new THREE.BoxGeometry(0.12, 0.45, 0.06);
    const tStem = new THREE.Mesh(tStemGeo, rubyMetallicMaterial);
    tStem.position.set(-0.55, 0.05, 0);
    frontEmblemGroup.add(tTop, tStem);

    // Letter O (Torus / Ring)
    const oGeo = new THREE.TorusGeometry(0.24, 0.07, 16, 36);
    const oMesh = new THREE.Mesh(oGeo, rubyMetallicMaterial);
    oMesh.position.set(0, 0.13, 0);
    frontEmblemGroup.add(oMesh);

    // Letter K
    const kStemGeo = new THREE.BoxGeometry(0.12, 0.55, 0.06);
    const kStem = new THREE.Mesh(kStemGeo, rubyMetallicMaterial);
    kStem.position.set(0.48, 0.13, 0);
    const kArm1Geo = new THREE.BoxGeometry(0.3, 0.1, 0.06);
    const kArm1 = new THREE.Mesh(kArm1Geo, rubyMetallicMaterial);
    kArm1.rotation.z = Math.PI / 4;
    kArm1.position.set(0.65, 0.25, 0);
    const kArm2Geo = new THREE.BoxGeometry(0.32, 0.1, 0.06);
    const kArm2 = new THREE.Mesh(kArm2Geo, rubyMetallicMaterial);
    kArm2.rotation.z = -Math.PI / 4;
    kArm2.position.set(0.67, 0.02, 0);
    frontEmblemGroup.add(kStem, kArm1, kArm2);

    // "COIN" Subtext banner bar
    const coinBannerGeo = new THREE.BoxGeometry(0.9, 0.12, 0.05);
    const coinBanner = new THREE.Mesh(coinBannerGeo, darkTitaniumMaterial);
    coinBanner.position.set(0, -0.35, 0);
    frontEmblemGroup.add(coinBanner);

    const frontEmblemMesh = tTop; // representative for finish switcher
    coinMasterGroup.add(frontEmblemGroup);

    // 4. Back Star Emblem (for reverse face)
    const backEmblemGroup = new THREE.Group();
    backEmblemGroup.position.set(0, 0, -0.11);
    const starGeom = new THREE.CylinderGeometry(0.5, 0.5, 0.05, 6);
    const backStarMesh = new THREE.Mesh(starGeom, rubyMetallicMaterial);
    backStarMesh.rotation.x = Math.PI / 2;
    backEmblemGroup.add(backStarMesh);
    coinMasterGroup.add(backEmblemGroup);

    // 5. Orbiting Gyro Ring 1 (Ruby Red, angled)
    const orbitRing1Geo = new THREE.TorusGeometry(1.65, 0.035, 16, 64);
    const orbitRing1 = new THREE.Mesh(orbitRing1Geo, rubyMetallicMaterial);
    orbitRing1.rotation.x = 1.1;
    scene.add(orbitRing1);

    // 6. Orbiting Gyro Ring 2 (Titanium, perpendicular)
    const orbitRing2Geo = new THREE.TorusGeometry(1.9, 0.03, 16, 64);
    const orbitRing2 = new THREE.Mesh(orbitRing2Geo, darkTitaniumMaterial);
    orbitRing2.rotation.y = 0.8;
    orbitRing2.rotation.x = -0.4;
    scene.add(orbitRing2);

    // 7. Node emitters on Orbit Ring 1
    const nodeGeo = new THREE.SphereGeometry(0.07, 16, 16);
    const nodeMesh1 = new THREE.Mesh(nodeGeo, neonRedAccentMaterial);
    const nodeMesh2 = new THREE.Mesh(nodeGeo, pureSilverMaterial);
    orbitRing1.add(nodeMesh1, nodeMesh2);
    nodeMesh1.position.set(1.65, 0, 0);
    nodeMesh2.position.set(-1.65, 0, 0);

    // 8. Procedural Particle Cyber Dust Field
    const particleCount = isSoftwareGl ? 60 : 160;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 6;
      particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 4;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 4;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0xe11d48,
      size: 0.045,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // 9. Soft Ground Radial Contact Shadow Plane
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sCtx = shadowCanvas.getContext('2d');
    if (sCtx) {
      const grad = sCtx.createRadialGradient(64, 64, 10, 64, 64, 60);
      grad.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
      grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.3)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 128, 128);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    shadowTexture.colorSpace = THREE.SRGBColorSpace;
    const shadowPlaneGeo = new THREE.PlaneGeometry(4, 4);
    const shadowPlaneMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
    });
    const shadowPlane = new THREE.Mesh(shadowPlaneGeo, shadowPlaneMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -1.6;
    scene.add(shadowPlane);

    // Apply default finish
    applyFinish('rubyGold');

    // Pointer event interaction
    const handlePointerDown = (e: PointerEvent) => {
      sceneStateRef.current.isPointerDown = true;
      sceneStateRef.current.pointerStartX = e.clientX;
      sceneStateRef.current.pointerStartY = e.clientY;
      setUserIsInteracting(true);
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!sceneStateRef.current.isPointerDown) return;
      const dx = e.clientX - sceneStateRef.current.pointerStartX;
      const dy = e.clientY - sceneStateRef.current.pointerStartY;
      sceneStateRef.current.pointerStartX = e.clientX;
      sceneStateRef.current.pointerStartY = e.clientY;
      sceneStateRef.current.targetRotationY += dx * 0.012;
      sceneStateRef.current.targetRotationX += dy * 0.012;
      // Clamp vertical tilt
      sceneStateRef.current.targetRotationX = Math.max(-0.8, Math.min(0.8, sceneStateRef.current.targetRotationX));
    };

    const handlePointerUp = () => {
      sceneStateRef.current.isPointerDown = false;
      setTimeout(() => setUserIsInteracting(false), 800);
    };

    const domEl = renderer.domElement;
    domEl.style.cursor = 'grab';
    domEl.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    // Animation & Pacing Loop
    let animId = 0;
    let lastTime = performance.now();

    function renderFrame() {
      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      const state = sceneStateRef.current;

      // Finish switcher check
      applyFinish(state.finish);

      // Auto rotation when enabled and not actively dragged
      if (state.rotating && !state.isPointerDown) {
        state.targetRotationY += 0.85 * dt;
      }

      // Exponential damping on orientation (smooth kinetic inertia)
      state.userRotationX += (state.targetRotationX - state.userRotationX) * (1 - Math.exp(-8 * dt));
      state.userRotationY += (state.targetRotationY - state.userRotationY) * (1 - Math.exp(-8 * dt));

      coinMasterGroup.rotation.x = state.userRotationX;
      coinMasterGroup.rotation.y = state.userRotationY;

      // Orbiting gyros rotate continuously with differential speeds
      orbitRing1.rotation.z += 0.45 * dt;
      orbitRing1.rotation.y += 0.3 * dt;
      orbitRing2.rotation.z -= 0.35 * dt;
      orbitRing2.rotation.x += 0.25 * dt;

      // Subtle particle float
      particles.rotation.y += 0.08 * dt;

      // Exploded View smooth spring transition
      state.exploded += (state.targetExploded - state.exploded) * (1 - Math.exp(-6 * dt));
      frontEmblemGroup.position.z = 0.11 + state.exploded * 0.55;
      backEmblemGroup.position.z = -0.11 - state.exploded * 0.55;
      orbitRing1.scale.setScalar(1 + state.exploded * 0.25);
      orbitRing2.scale.setScalar(1 + state.exploded * 0.35);

      renderer.render(scene, camera);
      animId = requestAnimationFrame(renderFrame);
    }

    animId = requestAnimationFrame(renderFrame);

    // Resize handling
    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      if (newW === 0 || newH === 0) return;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      domEl.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);

      // Dispose Three.js resources
      renderer.dispose();
      coinBodyGeo.dispose();
      coinRimGeo.dispose();
      tTopGeo.dispose();
      tStemGeo.dispose();
      oGeo.dispose();
      kStemGeo.dispose();
      kArm1Geo.dispose();
      kArm2Geo.dispose();
      coinBannerGeo.dispose();
      starGeom.dispose();
      orbitRing1Geo.dispose();
      orbitRing2Geo.dispose();
      nodeGeo.dispose();
      particleGeo.dispose();
      shadowPlaneGeo.dispose();
      goldMaterial.dispose();
      rubyMetallicMaterial.dispose();
      darkTitaniumMaterial.dispose();
      pureSilverMaterial.dispose();
      neonRedAccentMaterial.dispose();
      particleMat.dispose();
      shadowPlaneMat.dispose();
      shadowTexture.dispose();
      if (container.contains(domEl)) {
        container.removeChild(domEl);
      }
    };
  }, []);

  return (
    <div className={`relative w-full h-full flex flex-col items-center justify-center overflow-hidden select-none ${className}`}>
      {/* 3D WebGL Canvas Mount Container */}
      <div
        ref={mountRef}
        className="w-full h-full min-h-[300px] flex items-center justify-center cursor-grab active:cursor-grabbing"
      />

      {/* Floating Badge (Top Left) */}
      <div className="absolute top-3 left-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 border border-white/10 text-xs text-zinc-300 pointer-events-none">
        <Sparkles className="w-3.5 h-3.5 text-rose-500" />
        <span className="font-semibold text-white tracking-wide">TOK 3D VAULT</span>
        <span className="text-[10px] text-zinc-400 border-l border-zinc-700 pl-2">PBR Studio Core</span>
      </div>

      {/* Interaction hint */}
      {userIsInteracting && (
        <div className="absolute top-3 right-4 px-2.5 py-1 rounded bg-rose-950/70 border border-rose-500/30 text-[11px] text-rose-300 pointer-events-none animate-fadeIn">
          Rotando Token 3D
        </div>
      )}

      {/* Collapsible Ergonomic Bottom Dock (Three.js Directive: <= 15% viewport footprint, solid/rgba surfaces) */}
      {interactiveMode && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[92%] max-w-[500px] z-20">
          {/* Toggle Button */}
          <div className="flex justify-center -mb-2">
            <button
              onClick={() => setControlsCollapsed(!controlsCollapsed)}
              className="px-3 py-1 rounded-t-lg bg-zinc-900 border-t border-x border-zinc-800 text-[11px] font-medium text-zinc-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
              title="Colapsar / Expandir controles 3D"
            >
              <Sliders className="w-3 h-3 text-rose-500" />
              {controlsCollapsed ? 'Ver Controles 3D' : 'Ocultar'}
              {controlsCollapsed ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          </div>

          {!controlsCollapsed && (
            <div className="p-2.5 rounded-xl bg-zinc-950/95 border border-zinc-800 shadow-2xl flex flex-wrap items-center justify-between gap-2 text-xs">
              {/* Finish Swatches */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider">Acabado:</span>
                <button
                  onClick={() => setActiveFinish('rubyGold')}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-all cursor-pointer ${
                    activeFinish === 'rubyGold'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/60'
                      : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-white'
                  }`}
                >
                  Oro Rubí
                </button>
                <button
                  onClick={() => setActiveFinish('cyberObsidian')}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-all cursor-pointer ${
                    activeFinish === 'cyberObsidian'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/60'
                      : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-white'
                  }`}
                >
                  Obsidiana
                </button>
                <button
                  onClick={() => setActiveFinish('platinum')}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-all cursor-pointer ${
                    activeFinish === 'platinum'
                      ? 'bg-zinc-100 text-zinc-900 font-semibold border border-white'
                      : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-white'
                  }`}
                >
                  Platino
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1.5 ml-auto">
                <button
                  onClick={() => setIsExploded(!isExploded)}
                  className={`px-2.5 py-1 rounded flex items-center gap-1 text-[11px] transition-colors cursor-pointer ${
                    isExploded
                      ? 'bg-rose-600 text-white font-medium'
                      : 'bg-zinc-900 text-zinc-300 border border-zinc-800 hover:bg-zinc-800'
                  }`}
                  title="Modo despiece / vista explosionada de componentes"
                >
                  <Eye className="w-3 h-3" />
                  {isExploded ? 'Ensamblar' : 'Despiece'}
                </button>
                <button
                  onClick={() => setIsRotating(!isRotating)}
                  className={`p-1.5 rounded text-zinc-300 transition-colors cursor-pointer ${
                    isRotating ? 'bg-zinc-800 text-rose-400' : 'bg-zinc-900 text-zinc-500 hover:text-white'
                  }`}
                  title={isRotating ? 'Pausar giro automático' : 'Activar giro automático'}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
