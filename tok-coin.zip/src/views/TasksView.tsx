import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getAvailableTasksForSeed } from '../data/tasksData';
import { TaskItem, VipLevel } from '../types';
import { TaskModal } from '../components/TaskModal';
import { formatCOP } from '../config/vipConfig';
import {
  CheckCircle2,
  Lock,
  Play,
  Clock,
  Sparkles,
  AlertTriangle,
  Flame,
  ShieldCheck,
  Filter,
  Crown,
  Youtube,
} from 'lucide-react';

interface TasksViewProps {
  onTabChange: (tab: string) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({ onTabChange }) => {
  const { currentUser, vipConfig, getVipStatusForId, completeTask, currentDateStr } = useAuth();

  const [selectedTask, setSelectedTask] = useState<TaskItem | null>(null);
  const [selectedVipId, setSelectedVipId] = useState<string>(currentUser?.currentVipId || 'vip1');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [alertNotice, setAlertNotice] = useState<string | null>(null);

  if (!currentUser) return null;

  const currentVip = vipConfig[selectedVipId] || vipConfig.vip1;
  const isVipOwned = Boolean(currentUser.activeVips?.[selectedVipId] || currentUser.currentVipId === selectedVipId);
  const vipStatus = getVipStatusForId(selectedVipId);

  // Tasks completed today specifically for this VIP level
  const completedTodayForVip = currentUser.completedTasks.filter(
    (t) => t.dateStr === currentDateStr && t.vipId === selectedVipId
  );
  const completedTaskIdsTodayForVip = new Set(completedTodayForVip.map((t) => t.taskId));

  // Tasks list
  const allTasks = getAvailableTasksForSeed(currentDateStr);
  const filteredTasks = allTasks.filter((t) => {
    if (activeCategory === 'all') return true;
    return t.category === activeCategory;
  });

  const handleTaskClick = (task: TaskItem) => {
    setAlertNotice(null);

    // Check if user owns this VIP level
    if (!isVipOwned) {
      setAlertNotice(`No tienes activo el nivel ${currentVip.name}. Puedes adquirirlo en la sección VIP.`);
      return;
    }

    // Check if VIP is expired
    if (vipStatus.isExpired) {
      setAlertNotice(vipStatus.blockReason || `Tu membresía de ${currentVip.name} ha vencido.`);
      return;
    }

    // Check if VIP 1 cap reached
    if (vipStatus.vip1CapReached) {
      setAlertNotice(vipStatus.blockReason || 'Has alcanzado el límite de $5.000 COP de VIP 1.');
      return;
    }

    // Check if task already completed today for this VIP
    if (completedTaskIdsTodayForVip.has(task.id)) {
      setAlertNotice('Esta tarea ya fue completada hoy para este nivel VIP. Por favor selecciona otra.');
      return;
    }

    // Check if reached daily quota for this VIP
    if (completedTodayForVip.length >= vipStatus.dailyTasksLimit) {
      setAlertNotice(`Ya completaste las ${vipStatus.dailyTasksLimit} tareas de hoy para ${currentVip.name}.`);
      return;
    }

    setSelectedTask(task);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Top Header & Tally */}
      <div className="p-6 rounded-3xl tok-gradient-card border border-zinc-800 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
                Centro de Micro-Tareas de Video
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">Tareas Diarias TOK COIN</h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              Cada nivel VIP tiene sus tareas diarias independientes. Si tienes varios VIPs activos, puedes completar las tareas de cada nivel.
            </p>
          </div>

          {/* Daily Progress Gauge for Selected VIP */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex items-center gap-4 shrink-0">
            <div className="text-right">
              <p className="text-[10px] text-zinc-400 uppercase font-bold">
                {currentVip.name} • Hoy ({currentDateStr})
              </p>
              <p className="text-xl font-black text-white font-mono">
                {completedTodayForVip.length} / {currentVip.dailyTasks}
              </p>
              <p className="text-[11px] text-emerald-400 font-semibold">
                {completedTodayForVip.length >= currentVip.dailyTasks
                  ? '¡Tareas de hoy listas!'
                  : `${Math.max(0, currentVip.dailyTasks - completedTodayForVip.length)} pendientes`}
              </p>
            </div>
            <div className="w-12 h-12 rounded-full border-4 border-zinc-800 flex items-center justify-center font-bold text-xs text-white relative">
              <div
                className="absolute inset-0 rounded-full border-4 border-rose-500"
                style={{
                  clipPath: `polygon(0 0, 100% 0, 100% ${Math.min(
                    100,
                    (completedTodayForVip.length / (currentVip.dailyTasks || 1)) * 100
                  )}%, 0 ${Math.min(100, (completedTodayForVip.length / (currentVip.dailyTasks || 1)) * 100)}%)`,
                }}
              />
              <span className="relative z-10">
                {Math.round((completedTodayForVip.length / (currentVip.dailyTasks || 1)) * 100)}%
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic Alert Banner */}
        {alertNotice && (
          <div className="mt-4 p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/50 text-xs text-rose-200 flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{alertNotice}</span>
            </div>
            <button
              onClick={() => setAlertNotice(null)}
              className="text-xs text-rose-300 hover:text-white font-bold"
            >
              ✕
            </button>
          </div>
        )}
      </div>

      {/* Multi-VIP Level Selector Tabs (Independent Tasks per VIP) */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Crown className="w-3.5 h-3.5 text-rose-500" /> Selecciona el Nivel VIP a Trabajar:
          </span>
          <span className="text-[11px] text-zinc-500">Tareas independientes por membresía</span>
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {Object.values(vipConfig).map((lvl) => {
            const isOwned = Boolean(currentUser.activeVips?.[lvl.id] || currentUser.currentVipId === lvl.id);
            const isSelected = selectedVipId === lvl.id;
            const tasksDone = currentUser.completedTasks.filter(
              (t) => t.dateStr === currentDateStr && t.vipId === lvl.id
            ).length;

            return (
              <button
                key={lvl.id}
                onClick={() => {
                  setSelectedVipId(lvl.id);
                  setAlertNotice(null);
                }}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                  isSelected
                    ? 'border-rose-500 bg-rose-950/40 text-white ring-2 ring-rose-500 shadow-lg'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-white hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-black text-xs text-white">{lvl.name}</span>
                  {isOwned ? (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                      ACTIVO
                    </span>
                  ) : (
                    <Lock className="w-3 h-3 text-zinc-600" />
                  )}
                </div>
                <div className="mt-1 flex items-baseline justify-between text-[11px]">
                  <span className="font-mono text-emerald-400 font-bold">
                    +{formatCOP(lvl.rewardPerTask)}
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    {tasksDone}/{lvl.dailyTasks} hoy
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Warning banner if selected VIP is not acquired */}
      {!isVipOwned && (
        <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-zinc-800 text-zinc-400">
              <Lock className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">
                Nivel {currentVip.name} no está activo en tu cuenta
              </h4>
              <p className="text-xs text-zinc-400">
                Adquiere este nivel por{' '}
                <strong className="text-white font-mono">{formatCOP(currentVip.cost)} COP</strong> para desbloquear sus {currentVip.dailyTasks} tareas diarias y ganar {formatCOP(currentVip.dailyReward)} COP al día.
              </p>
            </div>
          </div>
          <button
            onClick={() => onTabChange('vip')}
            className="px-4 py-2 rounded-xl tok-gradient-red text-white font-bold text-xs shadow-md shrink-0 cursor-pointer"
          >
            Adquirir {currentVip.name}
          </button>
        </div>
      )}

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'all', label: 'Todos los videos' },
          { id: 'video', label: 'YouTube & Shorts' },
          { id: 'like', label: 'Likes & Interacción' },
          { id: 'share', label: 'Compartir' },
          { id: 'follow', label: 'Canales Oficiales' },
        ].map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCategory(c.id)}
            className={`px-3 py-1.5 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer ${
              activeCategory === c.id
                ? 'bg-zinc-100 text-zinc-950 font-bold'
                : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-white'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Tasks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTasks.map((task) => {
          const isDoneTodayForThisVip = completedTaskIdsTodayForVip.has(task.id);
          const isLocked = !isVipOwned || !vipStatus.canDoTasks;

          return (
            <div
              key={task.id}
              onClick={() => handleTaskClick(task)}
              className={`rounded-2xl border p-4 flex flex-col justify-between transition-all select-none cursor-pointer ${
                isDoneTodayForThisVip
                  ? 'bg-zinc-950/60 border-emerald-900/40 opacity-75'
                  : isLocked
                  ? 'bg-zinc-950/70 border-zinc-900 hover:border-zinc-800'
                  : 'tok-gradient-card border-zinc-800 hover:border-rose-500/60 hover:shadow-xl hover:-translate-y-0.5'
              }`}
            >
              <div className="space-y-3">
                {/* Thumbnail Preview & Badge */}
                <div className="relative aspect-video rounded-xl overflow-hidden bg-zinc-900 border border-zinc-800">
                  <img
                    src={task.thumbnail}
                    alt={task.title}
                    className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent flex flex-col justify-between p-2.5">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-full bg-black/80 text-[10px] font-bold text-white border border-white/10 flex items-center gap-1">
                        {task.youtubeId && <Youtube className="w-3 h-3 text-red-500" />}
                        {task.platform}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-rose-600/80 text-[10px] font-mono font-bold text-white">
                        {task.durationSeconds}s
                      </span>
                    </div>

                    <div className="flex items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow-lg">
                        <Play className="w-5 h-5 ml-0.5 fill-white" />
                      </div>
                    </div>

                    <div className="text-[11px] text-zinc-300 font-medium truncate">
                      {task.creator}
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-1">
                  <h3 className="font-bold text-sm text-white line-clamp-2 leading-tight">
                    {task.title}
                  </h3>
                  <p className="text-xs text-zinc-400 line-clamp-2">
                    {task.description}
                  </p>
                </div>
              </div>

              {/* Bottom Reward Strip for selected VIP */}
              <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-semibold text-zinc-500 block">
                    Recompensa ({currentVip.name})
                  </span>
                  <span className="font-mono font-extrabold text-sm text-emerald-400">
                    +{formatCOP(currentVip.rewardPerTask)} COP
                  </span>
                </div>

                {isDoneTodayForThisVip ? (
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-[11px] font-bold text-emerald-300 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Completada
                  </span>
                ) : isLocked ? (
                  <span className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] font-semibold text-zinc-500 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Bloqueada
                  </span>
                ) : (
                  <button className="px-3 py-1.5 rounded-xl tok-gradient-red text-white text-xs font-bold shadow-md flex items-center gap-1">
                    Iniciar <Play className="w-3 h-3 fill-white" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Task Execution Modal */}
      {selectedTask && (
        <TaskModal
          task={selectedTask}
          vip={currentVip}
          onClose={() => setSelectedTask(null)}
          onClaim={(t) => completeTask(t, selectedVipId)}
        />
      )}
    </div>
  );
};
