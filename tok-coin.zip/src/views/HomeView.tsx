import React from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO } from '../config/vipConfig';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Crown,
  Clock,
  Sparkles,
  ChevronRight,
  AlertTriangle,
  PlayCircle,
  Coins,
  MessageCircle,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

interface HomeViewProps {
  onTabChange: (tab: string) => void;
  onOpenRecharge: () => void;
  onOpenWithdraw: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onTabChange,
  onOpenRecharge,
  onOpenWithdraw,
}) => {
  const { currentUser, getVipStatus, getUserActiveVips, getTasksCompletedToday, companySettings, allTransactions } = useAuth();
  const vipStatus = getVipStatus();
  const activeVipsList = getUserActiveVips();
  const tasksToday = getTasksCompletedToday();

  if (!currentUser) return null;

  // Calculate VIP 1 earnings if currently on VIP 1
  const vip1Earned = currentUser.completedTasks
    .filter((t) => t.vipId === 'vip1')
    .reduce((sum, t) => sum + t.rewardCop, 0);

  const vip1Cap = vipStatus.level.totalCapLimit || 5000;
  const vip1CapPercentage = Math.min(100, Math.round((vip1Earned / vip1Cap) * 100));

  const userTransactions = allTransactions.filter(
    (t) => t.userId === currentUser.id || t.userAccountId === currentUser.accountId
  );

  return (
    <div className="space-y-6 pb-20">
      {/* Top Banner Warning if VIP is expired or cap reached */}
      {vipStatus.isExpired && (
        <div className="p-4 rounded-2xl bg-rose-950/70 border border-rose-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-rose-400 shrink-0" />
            <div>
              <h4 className="text-sm font-bold text-white">Nivel VIP Vencido</h4>
              <p className="text-xs text-rose-200">
                Tu período de {vipStatus.level.durationDays} días ha finalizado. Actualiza o adquiere tus niveles VIP para continuar realizando tareas y generando recompensas.
              </p>
            </div>
          </div>
          <button
            onClick={() => onTabChange('vip')}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg transition-colors shrink-0 cursor-pointer"
          >
            Renovar VIP
          </button>
        </div>
      )}

      {vipStatus.vip1CapReached && !vipStatus.isExpired && (
        <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
            <div>
              <h4 className="text-sm font-bold text-white">Límite de $5.000 COP Alcanzado (VIP 1)</h4>
              <p className="text-xs text-amber-200">
                Has alcanzado el tope máximo del nivel gratuito. Adquiere VIP 2 ($40.000 COP) para habilitar tareas diarias ilimitadas con saldo 100% retirable.
              </p>
            </div>
          </div>
          <button
            onClick={() => onTabChange('vip')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-lg transition-colors shrink-0 cursor-pointer"
          >
            Adquirir VIP 2
          </button>
        </div>
      )}

      {/* Main Account Balances & Status Card */}
      <div className="p-6 sm:p-7 rounded-3xl tok-gradient-card border border-zinc-800 shadow-2xl relative overflow-hidden space-y-6">
        <div className="absolute top-0 right-0 w-80 h-80 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-6 relative z-10">
          {/* Top row: Official Logo, Account & Active VIP Badges */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl overflow-hidden border border-rose-500/50 bg-black shadow-md shrink-0">
                <img src={OFFICIAL_TOK_LOGO} alt="TOK COIN Logo" className="w-full h-full object-cover" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-zinc-400 block">Cuenta Oficial Registrada</span>
                <span className="font-mono text-sm font-bold text-white tracking-wider">
                  {currentUser.accountId.slice(0, 3)}****{currentUser.accountId.slice(7)}
                </span>
              </div>
            </div>

            {/* Badges for all Active VIPs (Supports simultaneous VIPs) */}
            <div className="flex flex-wrap items-center gap-2">
              {activeVipsList.length > 0 ? (
                activeVipsList.map((av) => (
                  <div
                    key={av.level.id}
                    onClick={() => onTabChange('vip')}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold border flex items-center gap-1.5 cursor-pointer transition-transform hover:scale-105 ${av.level.badgeColor}`}
                  >
                    <Crown className="w-3.5 h-3.5" />
                    <span>{av.level.name}</span>
                    <span className="text-[10px] opacity-80">({av.daysRemaining}d)</span>
                  </div>
                ))
              ) : (
                <div
                  onClick={() => onTabChange('vip')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold border flex items-center gap-1.5 cursor-pointer ${vipStatus.level.badgeColor}`}
                >
                  <Crown className="w-3.5 h-3.5" />
                  <span>{vipStatus.level.name}</span>
                </div>
              )}
            </div>
          </div>

          {/* Split Balances: Saldo Retirable & Ganancias */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Saldo Retirable */}
            <div
              onClick={onOpenWithdraw}
              className="p-5 rounded-2xl bg-zinc-900/90 border border-emerald-500/40 hover:border-emerald-500 transition-all cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-1.5">
                  <Coins className="w-4 h-4" /> Saldo Retirable
                </span>
                <span className="text-[10px] font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                  VIP 2 a 5
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
                {formatCOP(currentUser.saldoCop)}
              </h2>
              <p className="text-[11px] text-zinc-400">Fondos disponibles para retiro bancario (Nequi, Daviplata, Bancolombia)</p>
            </div>

            {/* Ganancias (VIP 1 + Recargas QR) */}
            <div
              onClick={onOpenRecharge}
              className="p-5 rounded-2xl bg-zinc-900/90 border border-zinc-700 hover:border-rose-500 transition-all cursor-pointer space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider text-rose-400 font-bold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" /> Ganancias (Compras VIP)
                </span>
                <span className="text-[10px] font-bold text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">
                  NO RETIRABLE
                </span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
                {formatCOP(currentUser.gananciasCop)}
              </h2>
              <p className="text-[11px] text-zinc-400">Saldo acumulado por VIP 1 y recargas por QR para adquirir membresías</p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-zinc-800/80">
            <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
              <p className="text-[11px] text-zinc-400">Tareas Completadas Hoy</p>
              <p className="text-base sm:text-lg font-black text-white font-mono mt-0.5">
                {tasksToday.length} tareas
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
              <p className="text-[11px] text-zinc-400">Membresías Activas</p>
              <p className="text-base sm:text-lg font-black text-rose-400 font-mono mt-0.5 flex items-center gap-1.5">
                <Crown className="w-4 h-4" />
                {activeVipsList.length} Activas
              </p>
            </div>

            <div className="col-span-2 sm:col-span-1 p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80">
              <p className="text-[11px] text-zinc-400">Comisiones por Referidos (10%)</p>
              <p className="text-base sm:text-lg font-black text-amber-400 font-mono mt-0.5">
                {formatCOP(currentUser.totalCommissionsCop || 0)}
              </p>
            </div>
          </div>

          {/* VIP 1 Limit Progress Meter (if user is working on VIP 1) */}
          {(currentUser.currentVipId === 'vip1' || Boolean(currentUser.activeVips?.['vip1'])) && (
            <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-300 font-medium flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-rose-500" /> Tope VIP 1 Gratuito ($5.000 COP)
                </span>
                <span className="font-mono text-zinc-400 font-semibold">
                  {formatCOP(vip1Earned)} / {formatCOP(vip1Cap)}
                </span>
              </div>
              <div className="w-full bg-zinc-950 rounded-full h-2 overflow-hidden border border-zinc-800">
                <div
                  className={`h-full transition-all duration-500 ${
                    vip1CapPercentage >= 100 ? 'bg-amber-500' : 'bg-rose-600'
                  }`}
                  style={{ width: `${vip1CapPercentage}%` }}
                />
              </div>
              <p className="text-[11px] text-zinc-400 text-right">
                {vip1CapPercentage >= 100
                  ? '¡Límite alcanzado! Las tareas de VIP 1 están pausadas.'
                  : `Te faltan ${formatCOP(Math.max(0, vip1Cap - vip1Earned))} COP para el límite de VIP 1.`}
              </p>
            </div>
          )}
        </div>

        {/* Wallet Actions Buttons */}
        <div className="grid grid-cols-2 gap-3 mt-6 pt-4 border-t border-zinc-800/80 relative z-10">
          <button
            onClick={onOpenRecharge}
            className="py-3 px-4 rounded-xl tok-gradient-red text-white font-bold text-xs sm:text-sm tracking-wide shadow-lg hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer tok-glow-red"
          >
            <ArrowDownLeft className="w-4 h-4" /> Recargar QR
          </button>
          <button
            onClick={onOpenWithdraw}
            className="py-3 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold text-xs sm:text-sm tracking-wide transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowUpRight className="w-4 h-4 text-emerald-400" /> Retirar COP (15%)
          </button>
        </div>
      </div>

      {/* WhatsApp Official Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-zinc-900 to-zinc-950 border border-emerald-500/40 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-600/20 text-emerald-300 text-[11px] font-bold border border-emerald-500/30">
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" /> Comunidad Oficial WhatsApp
          </div>
          <h3 className="text-base sm:text-lg font-black text-white">
            Únete al Grupo Oficial de TOK COIN Colombia
          </h3>
          <p className="text-xs text-zinc-400">
            Atención prioritaria, comprobantes de pago de la comunidad y resolución de recargas.
          </p>
        </div>
        <a
          href={companySettings.whatsappGroupUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wide shadow-md transition-all shrink-0 flex items-center gap-1.5 cursor-pointer"
        >
          Unirse al Grupo Oficial <MessageCircle className="w-4 h-4" />
        </a>
      </div>

      {/* Quick Launch Action Banner: Start Daily Tasks */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-950/70 via-zinc-900 to-zinc-950 border border-rose-500/30 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-rose-600/30 text-rose-300 text-[11px] font-bold">
            <PlayCircle className="w-3.5 h-3.5" /> Tareas Diarias
          </div>
          <h3 className="text-lg font-black text-white">
            {vipStatus.canDoTasks
              ? `Realiza tus tareas diarias en tus niveles VIP activos`
              : 'Tareas del día completadas o bloqueadas'}
          </h3>
          <p className="text-xs text-zinc-400">
            Mira videos de 8 a 10 segundos y genera ganancias diarias por cada membresía activa.
          </p>
        </div>

        <button
          onClick={() => onTabChange('tasks')}
          className="py-3 px-6 rounded-xl tok-gradient-red text-white font-bold text-xs sm:text-sm tracking-wide shadow-lg hover:opacity-95 transition-all flex items-center gap-2 shrink-0 cursor-pointer tok-glow-red"
        >
          Ir a Tareas Diarias <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Recent Movements Feed */}
      <div className="rounded-3xl bg-zinc-950 border border-zinc-800 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">Últimos Movimientos de tu Cuenta</h3>
          <button
            onClick={() => onTabChange('wallet')}
            className="text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            Ver todos los movimientos →
          </button>
        </div>

        {userTransactions.length === 0 ? (
          <p className="text-xs text-zinc-500 py-4 text-center">No hay transacciones registradas todavía.</p>
        ) : (
          <div className="divide-y divide-zinc-900">
            {userTransactions.slice(0, 4).map((tx) => (
              <div key={tx.id} className="py-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                      tx.amount >= 0
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}
                  >
                    {tx.amount >= 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div>
                    <p className="font-semibold text-white">{tx.description}</p>
                    <p className="text-[10px] text-zinc-500">
                      {tx.dateStr} • {tx.method || 'TOK'}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`font-mono font-bold ${
                      tx.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {tx.amount >= 0 ? '+' : ''}
                    {formatCOP(tx.amount)} COP
                  </span>
                  <span
                    className={`block text-[10px] uppercase font-bold ${
                      tx.status === 'completado'
                        ? 'text-emerald-400'
                        : tx.status === 'pendiente'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
