import { VipLevel, CompanySettings } from '../types';

export const OFFICIAL_TOK_LOGO = '/assets/aistudio/IMG-20261016-WA8676_8010d260.jpg';

// The 3 official Colombian payment QR codes provided by user
export const OFFICIAL_QR_IMAGES = [
  '/assets/aistudio/IMG-20261021-WA0248_9eadbf45.jpg',
  '/assets/aistudio/IMG-20261021-WA7168_3738f806.jpg',
  '/assets/aistudio/IMG-20261021-WA0276_9a415d01.jpg',
];

export const DEFAULT_COMPANY_SETTINGS: CompanySettings = {
  whatsappGroupUrl: 'https://chat.whatsapp.com/Jl3F8cS7ATfF057f7HycHY?s=cl&p=a&mlu=4&ilr=4',
  companyQrImageUrl: '/assets/aistudio/IMG-20261016-WA8676_8010d260.jpg',
  nequiNumber: '3138124943',
  daviplataNumber: '3138124943',
  bancolombiaAccount: '245-891043-12 (Ahorros)',
  allowWithdrawalsAnytimeForTesting: false,
};

export const DEFAULT_VIP_LEVELS: Record<string, VipLevel> = {
  vip1: {
    id: 'vip1',
    level: 1,
    name: 'VIP 1 Gratuito',
    cost: 0,
    dailyTasks: 5,
    dailyReward: 900, // $900 COP diarios ($180 COP por cada una de las 5 tareas)
    rewardPerTask: 180, // 900 / 5
    durationDays: 2,
    totalEstimated: 1800,
    totalCapLimit: 5000, // Límite total de $5.000 COP (al alcanzarlo se bloquean las tareas)
    badgeColor: 'border-white/40 text-white bg-white/10',
    isFree: true,
    tagline: '5 tareas diarias, 2 días, $900 COP diarios, límite total de $5.000 COP.',
  },
  vip2: {
    id: 'vip2',
    level: 2,
    name: 'VIP 2',
    cost: 40000,
    dailyTasks: 5,
    dailyReward: 1300,
    rewardPerTask: 260, // 1300 / 5
    durationDays: 60,
    totalEstimated: 78000, // 60 * 1300
    badgeColor: 'border-red-500/50 text-red-400 bg-red-950/40',
    isFree: false,
    tagline: '5 tareas diarias, $1.300 diarios, 60 días activos. Total estimado $78.000 COP.',
  },
  vip3: {
    id: 'vip3',
    level: 3,
    name: 'VIP 3',
    cost: 100000,
    dailyTasks: 7,
    dailyReward: 2000,
    rewardPerTask: 285.71, // 2000 / 7
    durationDays: 90,
    totalEstimated: 180000, // 90 * 2000
    badgeColor: 'border-red-600/70 text-red-300 bg-red-900/40',
    isFree: false,
    tagline: '7 tareas diarias, $2.000 diarios, 90 días activos. Total estimado $180.000 COP.',
  },
  vip4: {
    id: 'vip4',
    level: 4,
    name: 'VIP 4',
    cost: 150000,
    dailyTasks: 7,
    dailyReward: 2500,
    rewardPerTask: 357.14, // 2500 / 7
    durationDays: 90,
    totalEstimated: 225000, // 90 * 2500
    badgeColor: 'border-rose-500/80 text-rose-300 bg-rose-950/50',
    isFree: false,
    tagline: '7 tareas diarias, $2.500 diarios, 90 días activos. Total estimado $225.000 COP.',
  },
  vip5: {
    id: 'vip5',
    level: 5,
    name: 'VIP 5',
    cost: 200000,
    dailyTasks: 9,
    dailyReward: 4500,
    rewardPerTask: 500, // 4500 / 9
    durationDays: 90,
    totalEstimated: 405000, // 90 * 4500
    badgeColor: 'border-red-500 text-white bg-gradient-to-r from-red-600 to-rose-700',
    isFree: false,
    tagline: '9 tareas diarias, $4.500 diarios, 90 días activos. Total estimado $405.000 COP.',
  },
};

const VIP_STORAGE_KEY = 'tok_coin_vip_config_v3';
const SETTINGS_STORAGE_KEY = 'tok_coin_company_settings_v2';

export function loadVipConfig(): Record<string, VipLevel> {
  try {
    const raw = localStorage.getItem(VIP_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_VIP_LEVELS, ...parsed };
    }
  } catch (err) {
    console.error('Error loading custom VIP config:', err);
  }
  return DEFAULT_VIP_LEVELS;
}

export function saveVipConfig(config: Record<string, VipLevel>): void {
  try {
    localStorage.setItem(VIP_STORAGE_KEY, JSON.stringify(config));
  } catch (err) {
    console.error('Error saving VIP config:', err);
  }
}

export function resetVipConfig(): Record<string, VipLevel> {
  localStorage.removeItem(VIP_STORAGE_KEY);
  return DEFAULT_VIP_LEVELS;
}

export function loadCompanySettings(): CompanySettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_COMPANY_SETTINGS, ...parsed };
    }
  } catch (err) {
    console.error('Error loading settings:', err);
  }
  return DEFAULT_COMPANY_SETTINGS;
}

export function saveCompanySettings(settings: CompanySettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Error saving settings:', err);
  }
}

// Format COP currency
export function formatCOP(amount: number): string {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Validates withdrawal schedule according to Colombian time:
 * Jueves (4), Viernes (5), Sábado (6), Domingo (0).
 * 1:00 p.m. a 5:00 p.m. (13:00 a 17:00) hora de Colombia (America/Bogota, UTC-5).
 */
export function checkWithdrawalSchedule(allowAnytime = false): {
  allowed: boolean;
  message: string;
  dayName: string;
  timeStr: string;
} {
  if (allowAnytime) {
    return {
      allowed: true,
      message: 'Horario habilitado (Modo Administrador / Pruebas activo).',
      dayName: 'Modo Pruebas',
      timeStr: 'Habilitado 24/7',
    };
  }

  // Get current time in Colombia
  const now = new Date();
  const colombiaTimeString = now.toLocaleString('en-US', { timeZone: 'America/Bogota' });
  const colDate = new Date(colombiaTimeString);

  const dayOfWeek = colDate.getDay(); // 0 = Domingo, 4 = Jueves, 5 = Viernes, 6 = Sábado
  const hour = colDate.getHours();
  const minute = colDate.getMinutes();

  const daysMap = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const dayName = daysMap[dayOfWeek];
  const timeFormatted = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;

  const isAllowedDay = dayOfWeek === 4 || dayOfWeek === 5 || dayOfWeek === 6 || dayOfWeek === 0;
  // 1:00 p.m. (13:00) to 5:00 p.m. (17:00)
  const isAllowedHour = (hour >= 13 && hour < 17) || (hour === 17 && minute === 0);

  if (!isAllowedDay) {
    return {
      allowed: false,
      message: `Hoy es ${dayName}. Los retiros solo se procesan de Jueves a Domingo de 1:00 p.m. a 5:00 p.m. (Hora de Colombia).`,
      dayName,
      timeStr: `${timeFormatted} COL`,
    };
  }

  if (!isAllowedHour) {
    return {
      allowed: false,
      message: `Hora actual en Colombia: ${timeFormatted}. El horario de retiros es exclusivamente de 1:00 p.m. a 5:00 p.m.`,
      dayName,
      timeStr: `${timeFormatted} COL`,
    };
  }

  return {
    allowed: true,
    message: `Horario de retiro activo (${dayName} ${timeFormatted} COL). Procesamiento en hasta 24 horas.`,
    dayName,
    timeStr: `${timeFormatted} COL`,
  };
}
