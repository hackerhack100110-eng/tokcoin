import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO, OFFICIAL_QR_IMAGES } from '../config/vipConfig';
import {
  X,
  QrCode,
  Upload,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Clock,
  Sparkles,
  ShieldCheck,
  RotateCw,
} from 'lucide-react';

interface RechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RechargeModal: React.FC<RechargeModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, companySettings, requestRecharge } = useAuth();
  const [amount, setAmount] = useState<number>(40000);
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedAccount, setCopiedAccount] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dynamic 2-minute (120 seconds) Random QR Rotation
  // Starts with a random QR from OFFICIAL_QR_IMAGES
  const [currentQrIndex, setCurrentQrIndex] = useState<number>(() =>
    Math.floor(Math.random() * OFFICIAL_QR_IMAGES.length)
  );
  const [secondsLeft, setSecondsLeft] = useState<number>(120);
  const [isQrTransitioning, setIsQrTransitioning] = useState<boolean>(false);

  // 2-Minute (120-second) interval for automated randomized rotation
  useEffect(() => {
    if (!isOpen) return;

    // Timer countdown
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          // Trigger transition animation
          setIsQrTransitioning(true);

          setTimeout(() => {
            // Pick a random QR different from current
            setCurrentQrIndex((oldIdx) => {
              const otherIndices = [0, 1, 2].filter((i) => i !== oldIdx);
              const nextRandom = otherIndices[Math.floor(Math.random() * otherIndices.length)];
              return nextRandom;
            });
            setIsQrTransitioning(false);
          }, 400);

          return 120; // reset to 2 minutes (120 seconds)
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen || !currentUser) return null;

  const currentQrSrc = OFFICIAL_QR_IMAGES[currentQrIndex] || OFFICIAL_QR_IMAGES[0];

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAccount(label);
    setTimeout(() => setCopiedAccount(null), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFeedback({ type: 'error', message: 'Por favor selecciona un archivo de imagen válido (JPG, PNG).' });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setReceiptImage(event.target?.result as string);
      setFileName(file.name);
      setFeedback(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (amount < 10000) {
      setFeedback({ type: 'error', message: 'El importe mínimo de recarga es de $10.000 COP.' });
      return;
    }

    if (!receiptImage) {
      setFeedback({ type: 'error', message: 'Debes subir la foto del comprobante desde tu galería.' });
      return;
    }

    setIsSubmitting(true);
    const res = requestRecharge(amount, `Código QR Dinámico #${currentQrIndex + 1}`, receiptImage);
    setIsSubmitting(false);

    if (res.success) {
      setFeedback({ type: 'success', message: res.message });
      setTimeout(() => {
        setFeedback(null);
        setReceiptImage(null);
        onClose();
      }, 3200);
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn select-none">
      <div className="relative w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-rose-500/40 bg-black shrink-0">
              <img src={OFFICIAL_TOK_LOGO} alt="TOK COIN Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Recargar Cuenta TOK COIN</h3>
              <p className="text-xs text-zinc-400">Escanea el código QR y sube tu comprobante</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-5 text-xs sm:text-sm">
          {/* Validation Notice */}
          <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200/90 text-xs flex items-start gap-2.5">
            <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>Verificación Administrativa:</strong> Tras escanear el QR y subir el comprobante de tu galería, el administrador verificará el pago y acreditará el saldo en tu balance de <strong>Ganancias (para compra VIP)</strong>.
            </span>
          </div>

          {/* Feedback */}
          {feedback && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-center gap-2.5 animate-fadeIn ${
                feedback.type === 'success'
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              )}
              <span>{feedback.message}</span>
            </div>
          )}

          {/* DYNAMIC 30-SECOND ROTATING QR CODE SECTION */}
          <div className="p-4 rounded-3xl bg-zinc-900/90 border border-zinc-800 flex flex-col items-center gap-3">
            <div className="flex items-center justify-between w-full text-xs px-1">
              <span className="font-bold text-white flex items-center gap-1.5">
                <QrCode className="w-4 h-4 text-rose-500" /> Código QR Oficial de Pago
              </span>
              {/* Automated 2-Minute Countdown Badge */}
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-950 border border-zinc-700 text-[11px] font-mono text-zinc-300">
                <RotateCw className="w-3 h-3 text-rose-400 animate-spin" />
                <span>
                  Rotando en {Math.floor(secondsLeft / 60)}:{String(secondsLeft % 60).padStart(2, '0')} min
                </span>
              </div>
            </div>

            {/* QR Image Frame - Exactly as uploaded, no background change, crystal clear */}
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-2xl overflow-hidden bg-white shadow-2xl border-4 border-zinc-700 flex items-center justify-center p-1">
              <img
                src={currentQrSrc}
                alt={`Código QR Oficial #${currentQrIndex + 1}`}
                className={`w-full h-full object-contain transition-all duration-500 ${
                  isQrTransitioning ? 'opacity-0 scale-95 blur-sm' : 'opacity-100 scale-100 blur-0'
                }`}
                style={{ imageRendering: 'pixelated' }}
              />
            </div>

            {/* 2-Minute Animated Progress Bar */}
            <div className="w-full bg-zinc-950 rounded-full h-1.5 overflow-hidden border border-zinc-800">
              <div
                className="bg-gradient-to-r from-red-600 to-rose-400 h-full transition-all duration-1000 ease-linear"
                style={{ width: `${(secondsLeft / 120) * 100}%` }}
              />
            </div>

            <p className="text-[11px] text-zinc-400 text-center">
              Abre tu app bancaria (Nequi, Daviplata o Bancolombia) y escanea este código QR para transferir.
            </p>
          </div>

          {/* Amount Selection */}
          <div>
            <label className="block text-zinc-400 text-xs font-semibold mb-1.5">
              1. Importe transferido (COP):
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 mb-2">
              {[20000, 40000, 100000, 150000, 200000].map((amt) => (
                <button
                  type="button"
                  key={amt}
                  onClick={() => setAmount(amt)}
                  className={`py-1.5 px-1 rounded-lg border text-center font-mono text-xs cursor-pointer ${
                    amount === amt
                      ? 'border-rose-500 bg-rose-950/40 text-white font-bold'
                      : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:text-white'
                  }`}
                >
                  ${amt / 1000}k
                </button>
              ))}
            </div>
            <input
              type="number"
              step="5000"
              min="10000"
              required
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none"
              placeholder="Ej: 40000"
            />
          </div>

          {/* Upload Receipt Image from Gallery */}
          <div>
            <label className="block text-zinc-400 text-xs font-semibold mb-1.5 flex items-center justify-between">
              <span>2. Subir comprobante desde tu galería:</span>
              <span className="text-rose-400 text-[11px] font-normal">Obligatorio</span>
            </label>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {receiptImage ? (
              <div className="relative rounded-2xl overflow-hidden border border-emerald-500/50 bg-black/80 p-2 space-y-2">
                <div className="relative aspect-video max-h-48 rounded-xl overflow-hidden bg-zinc-900 flex items-center justify-center">
                  <img src={receiptImage} alt="Comprobante cargado" className="w-full h-full object-contain" />
                </div>
                <div className="flex items-center justify-between px-2 text-xs">
                  <span className="text-emerald-400 font-medium truncate max-w-[200px] flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> {fileName || 'Comprobante listo'}
                  </span>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs text-rose-400 hover:text-rose-300 font-semibold underline cursor-pointer"
                  >
                    Cambiar imagen
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full p-6 rounded-2xl border-2 border-dashed border-zinc-700 hover:border-rose-500/80 bg-zinc-900/40 hover:bg-zinc-900/70 transition-all flex flex-col items-center justify-center gap-2 text-zinc-400 hover:text-white cursor-pointer"
              >
                <div className="p-3 rounded-full bg-zinc-800 text-rose-500">
                  <Upload className="w-6 h-6" />
                </div>
                <span className="font-semibold text-xs text-zinc-200">
                  Toca aquí para seleccionar el comprobante de tu galería
                </span>
                <span className="text-[11px] text-zinc-500">Captura de pantalla de la transferencia (JPG, PNG)</span>
              </button>
            )}
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting || !receiptImage}
              className={`w-full py-3.5 rounded-xl font-bold text-sm tracking-wide shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                !receiptImage
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  : 'tok-gradient-red text-white hover:opacity-95 tok-glow-red'
              }`}
            >
              {isSubmitting ? (
                'Enviando a verificación...'
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Enviar Comprobante ({formatCOP(amount)} COP)
                </>
              )}
            </button>
            <p className="text-[10px] text-zinc-500 text-center mt-2">
              Al aprobarse, se acreditará en "Ganancias" para la compra de VIPs y tu patrocinador recibirá el 10% de comisión automática.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
