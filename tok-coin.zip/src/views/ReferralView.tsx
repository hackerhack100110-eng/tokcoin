import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { OFFICIAL_TOK_LOGO, formatCOP } from '../config/vipConfig';
import { Users, Copy, Check, Share2, Gift, TrendingUp, Award, ShieldCheck, MessageCircle } from 'lucide-react';

export const ReferralView: React.FC = () => {
  const { currentUser, allUsersList, companySettings, allTransactions } = useAuth();
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!currentUser) return null;

  const inviteLink = `${window.location.origin}/#ref=${currentUser.referralCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentUser.referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Invited team members (users who registered with this user's referral code)
  const myDirectInvited = allUsersList.filter((u) => u.referredBy === currentUser.referralCode);

  // My commission transactions
  const myCommissions = allTransactions.filter(
    (t) =>
      (t.userId === currentUser.id || t.userAccountId === currentUser.accountId) &&
      t.type === 'comision_referido'
  );

  return (
    <div className="space-y-6 pb-20">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl tok-gradient-card border border-zinc-800 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/60 border border-rose-500/30 text-xs text-rose-300 font-bold">
              <Gift className="w-3.5 h-3.5 text-rose-500" /> PROGRAMA OFICIAL DE INVITACIONES
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Gana 10% de Comisión Automática
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              Recibe automáticamente el <strong>10% sobre cada recarga aprobada</strong> de los miembros que invites con tu código único. La comisión se acredita directamente a tu <strong>"Saldo Retirable"</strong>.
            </p>
          </div>

          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl overflow-hidden border-2 border-red-500/50 bg-black shadow-xl shrink-0 self-start md:self-center">
            <img src={OFFICIAL_TOK_LOGO} alt="Logo TOK COIN" className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Unique Referral Code Cards */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Code Box */}
          <div className="p-5 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex flex-col justify-between space-y-3">
            <div>
              <span className="text-[11px] text-zinc-400 uppercase font-semibold">
                Tu Código Único de Invitación:
              </span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-2xl sm:text-3xl font-black text-rose-500 font-mono tracking-widest">
                  {currentUser.referralCode}
                </span>
                <button
                  onClick={handleCopyCode}
                  className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-zinc-700"
                >
                  {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  {copiedCode ? '¡Copiado!' : 'Copiar Código'}
                </button>
              </div>
            </div>
            <p className="text-[11px] text-zinc-500">
              Pega este código en el campo de registro de tus amigos.
            </p>
          </div>

          {/* Link Box */}
          <div className="p-5 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex flex-col justify-between space-y-3">
            <div>
              <span className="text-[11px] text-zinc-400 uppercase font-semibold">
                Enlace Directo de Registro:
              </span>
              <div className="flex items-center justify-between mt-1 bg-zinc-950 p-2 rounded-xl border border-zinc-800">
                <span className="text-xs font-mono text-zinc-300 truncate max-w-[200px] sm:max-w-[240px]">
                  {inviteLink}
                </span>
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 rounded-lg tok-gradient-red text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
                  {copiedLink ? '¡Listo!' : 'Copiar Link'}
                </button>
              </div>
            </div>
            <p className="text-[11px] text-zinc-500">
              Acceso directo para nuevos registros.
            </p>
          </div>
        </div>
      </div>

      {/* Example Calculation Card from prompt */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-zinc-950 via-zinc-900 to-rose-950/40 border border-zinc-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-base">Ejemplo de Comisión del 10%</h3>
          </div>
          <p className="text-xs text-zinc-300">
            Si tu invitado recarga <strong className="text-white font-mono">$40.000 COP</strong> para adquirir VIP 2, recibirás al instante <strong className="text-emerald-400 font-mono">+$4.000 COP</strong> en tu "Saldo Retirable" una vez verificada la recarga.
          </p>
        </div>
        <div className="p-3 rounded-2xl bg-zinc-900/90 border border-zinc-800 text-right shrink-0">
          <span className="text-[10px] text-zinc-500 uppercase font-semibold block">Total Ganado en Comisiones</span>
          <span className="text-xl font-black text-emerald-400 font-mono">
            {formatCOP(currentUser.totalCommissionsCop || 0)} COP
          </span>
        </div>
      </div>

      {/* Direct Invited Team Members List */}
      <div className="rounded-3xl bg-zinc-950 border border-zinc-800 p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-rose-500" />
            <h3 className="text-base font-bold text-white">Tus Invitados Directos ({myDirectInvited.length})</h3>
          </div>
          <a
            href={companySettings.whatsappGroupUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5" /> Grupo de WhatsApp Oficial
          </a>
        </div>

        {myDirectInvited.length === 0 ? (
          <div className="p-8 text-center space-y-2 bg-zinc-900/30 rounded-2xl border border-zinc-900">
            <p className="text-sm font-semibold text-zinc-300">Aún no tienes invitados directos registrados</p>
            <p className="text-xs text-zinc-500">
              Comparte tu código <strong className="text-rose-400">{currentUser.referralCode}</strong> para empezar a generar el 10% de comisión por cada recarga aprobada.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-zinc-900">
            {myDirectInvited.map((member, idx) => (
              <div key={member.accountId} className="py-3.5 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center font-bold text-zinc-300">
                    {idx + 1}
                  </div>
                  <div>
                    <p className="font-bold text-white">
                      Cuenta: {member.accountId.slice(0, 3)}****{member.accountId.slice(7)} ({member.fullName || 'Usuario'})
                    </p>
                    <p className="text-[10px] text-zinc-500">
                      Nivel Actual: <span className="uppercase text-rose-400 font-bold">{member.currentVipId}</span>
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                    10% ACTIVO
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Commissions Log */}
      {myCommissions.length > 0 && (
        <div className="rounded-3xl bg-zinc-950 border border-zinc-800 p-6 space-y-3 shadow-xl">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" /> Historial de Comisiones Liquidadas
          </h4>
          <div className="divide-y divide-zinc-900 text-xs">
            {myCommissions.map((c) => (
              <div key={c.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-white">{c.description}</p>
                  <p className="text-[10px] text-zinc-500">{c.dateStr}</p>
                </div>
                <span className="font-mono font-bold text-emerald-400">+{formatCOP(c.amount)} COP</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
