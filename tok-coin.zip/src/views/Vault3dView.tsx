import React from 'react';
import { ThreeTokCoin } from '../components/ThreeTokCoin';
import { useAuth } from '../context/AuthContext';
import { formatCOP } from '../config/vipConfig';
import { Sparkles, ShieldCheck, Cpu, Layers, Disc3 } from 'lucide-react';

export const Vault3dView: React.FC = () => {
  const { currentUser, getVipStatus } = useAuth();
  const vipStatus = getVipStatus();

  return (
    <div className="relative w-full h-[calc(100vh-140px)] min-h-[550px] rounded-3xl bg-black border border-zinc-800 shadow-2xl overflow-hidden flex flex-col justify-between">
      {/* Three.js Full Bleed WebGL Canvas Viewport */}
      <div className="absolute inset-0 z-0">
        <ThreeTokCoin className="w-full h-full" interactiveMode={true} />
      </div>

      {/* Top HUD Overlay (Non-occluding, minimalist spec badges as per Three.js skill guidelines) */}
      <div className="relative z-10 p-4 sm:p-6 flex flex-wrap items-start justify-between gap-4 pointer-events-none">
        {/* Left Specification Card */}
        <div className="p-3.5 rounded-2xl bg-zinc-950/90 border border-zinc-800 text-xs space-y-1.5 shadow-xl max-w-xs pointer-events-auto">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="font-extrabold text-white text-sm">TOK TOKEN 3D CORE</span>
          </div>
          <p className="text-[11px] text-zinc-400">
            Modelo procedimental PBR de 10 piezas compuestas: Núcleo acanalado, bisel de oro cepillado, anillos giroscópicos con emissive ruby y sombra de contacto radial.
          </p>
          <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-[10px] text-zinc-400">
            <span>Render: <strong className="text-white">Three.js r160+ PBR</strong></span>
            <span>ToneMap: <strong className="text-rose-400">ACES Filmic</strong></span>
          </div>
        </div>

        {/* Right User Token Stats */}
        {currentUser && (
          <div className="p-3.5 rounded-2xl bg-zinc-950/90 border border-zinc-800 text-xs space-y-1 shadow-xl pointer-events-auto text-right">
            <span className="text-[10px] uppercase font-bold text-zinc-500">Membresía Asociada</span>
            <p className="font-bold text-white text-sm">{vipStatus.level.name}</p>
            <p className="font-mono text-emerald-400 font-extrabold text-sm">
              Saldo: {formatCOP(currentUser.saldoCop)} COP
            </p>
          </div>
        )}
      </div>

      {/* Center Subtext Guide */}
      <div className="relative z-10 self-center text-center pointer-events-none mb-16 opacity-75">
        <p className="text-[11px] font-semibold text-zinc-500 uppercase tracking-widest">
          Inspección Háptica 3D • Arrastra para Orbitar • Despiece en la Base
        </p>
      </div>
    </div>
  );
};
