import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO, checkWithdrawalSchedule } from '../config/vipConfig';
import {
  X,
  ArrowUpRight,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Lock,
  Clock,
  Calendar,
  CreditCard,
  UserCheck,
} from 'lucide-react';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, companySettings, requestWithdrawal } = useAuth();
  const [amount, setAmount] = useState<number>(20000);
  const [bankMethod, setBankMethod] = useState<string>('Nequi');
  const [destinationAccount, setDestinationAccount] = useState<string>(currentUser?.accountId || '');
  const [fullName, setFullName] = useState<string>(currentUser?.fullName || '');
  const [passwordAttempt, setPasswordAttempt] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen || !currentUser) return null;

  // Schedule check according to Colombian timezone
  const schedule = checkWithdrawalSchedule(companySettings.allowWithdrawalsAnytimeForTesting);

  // Calculations
  const requestedAmount = Math.max(0, amount);
  const fee15 = Math.round(requestedAmount * 0.15);
  const netAmount = Math.max(0, requestedAmount - fee15);
  const remainingSaldo = Math.max(0, currentUser.saldoCop - requestedAmount);
  const hasSufficientSaldo = currentUser.saldoCop >= requestedAmount && requestedAmount >= 10000;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!schedule.allowed) {
      setFeedback({ type: 'error', message: schedule.message });
      return;
    }

    if (requestedAmount < 10000) {
      setFeedback({ type: 'error', message: 'El importe mínimo de retiro es de $10.000 COP.' });
      return;
    }

    if (requestedAmount > currentUser.saldoCop) {
      setFeedback({
        type: 'error',
        message: `Saldo retirable insuficiente. Tu "Saldo" disponible es de ${formatCOP(currentUser.saldoCop)}.`,
      });
      return;
    }

    if (!passwordAttempt || passwordAttempt.trim().length < 6) {
      setFeedback({ type: 'error', message: 'Ingresa tu contraseña de acceso (PIN de 6 a 10 dígitos) para autorizar.' });
      return;
    }

    setIsSubmitting(true);
    const res = requestWithdrawal(requestedAmount, destinationAccount, fullName, passwordAttempt, bankMethod);
    setIsSubmitting(false);

    if (res.success) {
      setFeedback({ type: 'success', message: res.message });
      setPasswordAttempt('');
      setTimeout(() => {
        setFeedback(null);
        onClose();
      }, 3500);
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-rose-500/40 bg-black shrink-0">
              <img src={OFFICIAL_TOK_LOGO} alt="TOK COIN Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Solicitud de Retiro TOK COIN</h3>
              <p className="text-xs text-zinc-400">Transferencia a cuenta bancaria o billetera COP</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">
          {/* Colombian Schedule Status Pill */}
          <div
            className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
              schedule.allowed
                ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
            }`}
          >
            <Clock className={`w-4 h-4 shrink-0 mt-0.5 ${schedule.allowed ? 'text-emerald-400' : 'text-rose-400'}`} />
            <div className="space-y-0.5">
              <p className="font-bold flex items-center gap-1.5">
                <span>Horario Oficial de Retiros: Jueves a Domingo, 1:00 p.m. a 5:00 p.m. (COL)</span>
              </p>
              <p className="text-[11px] opacity-90">{schedule.message}</p>
            </div>
          </div>

          {/* Feedback */}
          {feedback && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-center gap-2.5 animate-fadeIn ${
                feedback.type === 'success'
                  ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-300'
                  : 'bg-rose-950/50 border-rose-500/50 text-rose-300'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              )}
              <span>{feedback.message}</span>
            </div>
          )}

          {/* Available Withdrawable Saldo */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-zinc-400 uppercase font-semibold">
                Saldo Retirable Disponible:
              </span>
              <p className="text-xl font-black text-emerald-400 font-mono mt-0.5">
                {formatCOP(currentUser.saldoCop)} COP
              </p>
            </div>
            <div className="text-right text-[11px] text-zinc-400">
              <span>Ganancias (VIP):</span>
              <p className="font-mono text-zinc-400">{formatCOP(currentUser.gananciasCop)}</p>
            </div>
          </div>

          {/* Form: Bank channel */}
          <div>
            <label className="block text-zinc-400 text-xs font-semibold mb-1.5">Destino de pago:</label>
            <div className="grid grid-cols-3 gap-2">
              {['Nequi', 'Daviplata', 'Bancolombia'].map((m) => (
                <button
                  type="button"
                  key={m}
                  onClick={() => setBankMethod(m)}
                  className={`py-2 px-3 rounded-xl border font-bold text-xs transition-all cursor-pointer ${
                    bankMethod === m
                      ? 'border-rose-500 bg-rose-950/30 text-rose-300'
                      : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:text-white'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-zinc-400 text-xs font-semibold mb-1">
              Nombre completo del titular bancario:
            </label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Ej: Carlos Alberto Mendoza"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs sm:text-sm focus:border-rose-500 outline-none"
            />
          </div>

          {/* Account Number */}
          <div>
            <label className="block text-zinc-400 text-xs font-semibold mb-1">
              Número de Cuenta / Teléfono ({bankMethod}):
            </label>
            <input
              type="text"
              required
              value={destinationAccount}
              onChange={(e) => setDestinationAccount(e.target.value)}
              placeholder="Ej: 3109876543"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-xs sm:text-sm focus:border-rose-500 outline-none"
            />
          </div>

          {/* Amount */}
          <div>
            <div className="flex items-center justify-between mb-1 text-xs">
              <label className="text-zinc-400 font-semibold">Importe a retirar (Mínimo $10.000 COP):</label>
              <button
                type="button"
                onClick={() => setAmount(currentUser.saldoCop)}
                className="text-rose-400 hover:text-rose-300 text-[11px] underline cursor-pointer"
              >
                Retirar Todo ({formatCOP(currentUser.saldoCop)})
              </button>
            </div>
            <input
              type="number"
              step="5000"
              min="10000"
              required
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none"
            />
          </div>

          {/* Transparent Cost Breakdown Preview */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-2 text-xs">
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">
              Desglose de Liquidación Obligatorio:
            </span>
            <div className="flex justify-between text-zinc-300">
              <span>Importe Solicitado:</span>
              <span className="font-mono font-bold text-white">{formatCOP(requestedAmount)} COP</span>
            </div>
            <div className="flex justify-between text-rose-400">
              <span>Comisión de Retiro (15%):</span>
              <span className="font-mono font-bold">-{formatCOP(fee15)} COP</span>
            </div>
            <div className="pt-2 border-t border-zinc-800 flex justify-between text-emerald-400 font-bold text-sm">
              <span>Importe Neto que Recibirás:</span>
              <span className="font-mono font-extrabold">{formatCOP(netAmount)} COP</span>
            </div>
            <div className="flex justify-between text-[11px] text-zinc-500 pt-1">
              <span>Saldo restante después de la reserva:</span>
              <span className="font-mono">{formatCOP(remainingSaldo)} COP</span>
            </div>
          </div>

          {/* Password Authorization */}
          <div>
            <label className="block text-zinc-400 text-xs font-semibold mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-rose-400" /> Contraseña de acceso (PIN de 6 a 10 dígitos):
            </label>
            <input
              type="password"
              required
              maxLength={10}
              value={passwordAttempt}
              onChange={(e) => setPasswordAttempt(e.target.value.replace(/\D/g, ''))}
              placeholder="••••••"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none tracking-widest"
            />
          </div>

          {/* Action Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting || !hasSufficientSaldo || !schedule.allowed}
              className={`w-full py-3.5 rounded-xl font-bold text-sm tracking-wide shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                !hasSufficientSaldo || !schedule.allowed
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  : 'tok-gradient-red text-white hover:opacity-95 tok-glow-red'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              Confirmar Retiro ({formatCOP(requestedAmount)} COP)
            </button>
            <p className="text-[10px] text-zinc-500 text-center mt-2">
              Procesamiento bancario garantizado en hasta 24 horas. El saldo queda reservado de inmediato. Si el administrador rechaza la solicitud, los fondos se devuelven automáticamente.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
