import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO } from '../config/vipConfig';
import {
  ShieldCheck,
  X,
  Users,
  CreditCard,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  Settings,
  Trash2,
  Check,
  Ban,
  Eye,
  PlusCircle,
  MinusCircle,
  Coins,
  AlertTriangle,
  MessageCircle,
  LogOut,
  Sparkles,
  Crown,
} from 'lucide-react';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose }) => {
  const {
    allUsersList,
    allTransactions,
    vipConfig,
    companySettings,
    adminApproveRecharge,
    adminRejectRecharge,
    adminApproveWithdrawal,
    adminRejectWithdrawal,
    adminBulkCreditAllUsers,
    adminAddUserBalance,
    adminRemoveUserBalance,
    adminManualActivateVip,
    adminDeleteUser,
    updateCompanySettings,
    adminLogout,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'users' | 'recharges' | 'withdrawals' | 'referrals' | 'settings'>('users');
  const [selectedReceiptImage, setSelectedReceiptImage] = useState<string | null>(null);

  // Bulk credit modal state
  const [bulkAmount, setBulkAmount] = useState<number>(5000);
  const [bulkConcept, setBulkConcept] = useState<string>('Comisión masiva de rendimiento TOK');
  const [showBulkModal, setShowBulkModal] = useState(false);

  // Modal: Agregar Saldo
  const [addBalanceTarget, setAddBalanceTarget] = useState<string | null>(null);
  const [addBalanceType, setAddBalanceType] = useState<'saldo' | 'ganancias'>('saldo');
  const [addBalanceAmount, setAddBalanceAmount] = useState<number>(10000);
  const [addBalanceReason, setAddBalanceReason] = useState<string>('Abono por recarga verificada');

  // Modal: Eliminar / Deducir Saldo
  const [removeBalanceTarget, setRemoveBalanceTarget] = useState<string | null>(null);
  const [removeBalanceType, setRemoveBalanceType] = useState<'saldo' | 'ganancias'>('saldo');
  const [removeBalanceAmount, setRemoveBalanceAmount] = useState<number>(5000);
  const [removeBalanceReason, setRemoveBalanceReason] = useState<string>('Corrección administrativa');

  // Modal: Activar VIP Manualmente
  const [vipTargetAccount, setVipTargetAccount] = useState<string | null>(null);
  const [selectedVipId, setSelectedVipId] = useState<string>('vip2');

  // Company settings local state
  const [localSettings, setLocalSettings] = useState(companySettings);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [withdrawalFilter, setWithdrawalFilter] = useState<'pendientes' | 'todos'>('pendientes');

  if (!isOpen) return null;

  // Filter transactions
  const pendingRecharges = allTransactions.filter((t) => t.type === 'recarga_qr' && t.status === 'pendiente');
  const allRecharges = allTransactions.filter((t) => t.type === 'recarga_qr');
  const pendingWithdrawals = allTransactions.filter((t) => t.type === 'retiro' && t.status === 'pendiente');
  const allWithdrawals = allTransactions.filter((t) => t.type === 'retiro');
  const displayedWithdrawals = withdrawalFilter === 'pendientes' ? pendingWithdrawals : allWithdrawals;
  const filteredUsers = allUsersList.filter((u) =>
    userSearch.trim() === ''
      ? true
      : u.accountId.includes(userSearch.trim()) ||
        (u.fullName && u.fullName.toLowerCase().includes(userSearch.toLowerCase())) ||
        u.referralCode.toLowerCase().includes(userSearch.toLowerCase())
  );
  const commissionTransactions = allTransactions.filter((t) => t.type === 'comision_referido');

  const showToast = (type: 'success' | 'error', text: string) => {
    setStatusMsg({ type, text });
    setTimeout(() => setStatusMsg(null), 3500);
  };

  const handleBulkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = adminBulkCreditAllUsers(bulkAmount, bulkConcept);
    if (res.success) {
      showToast('success', res.message);
      setShowBulkModal(false);
    } else {
      showToast('error', res.message);
    }
  };

  const handleAddBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addBalanceTarget) return;
    const res = adminAddUserBalance(addBalanceTarget, addBalanceType, addBalanceAmount, addBalanceReason);
    if (res.success) {
      showToast('success', res.message);
      setAddBalanceTarget(null);
    } else {
      showToast('error', res.message);
    }
  };

  const handleRemoveBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!removeBalanceTarget) return;
    const res = adminRemoveUserBalance(removeBalanceTarget, removeBalanceType, removeBalanceAmount, removeBalanceReason);
    if (res.success) {
      showToast('success', res.message);
      setRemoveBalanceTarget(null);
    } else {
      showToast('error', res.message);
    }
  };

  const handleVipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vipTargetAccount) return;
    const res = adminManualActivateVip(vipTargetAccount, selectedVipId);
    if (res.success) {
      showToast('success', res.message);
      setVipTargetAccount(null);
    } else {
      showToast('error', res.message);
    }
  };

  // Confirmation modal for deleting accounts (replaces window.confirm)
  const [accountToDelete, setAccountToDelete] = useState<string | null>(null);

  const handleDeleteUser = (accountId: string) => {
    setAccountToDelete(accountId);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanySettings(localSettings);
    showToast('success', 'Configuración de la empresa y canales de contacto actualizada.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn select-none">
      <div className="relative w-full max-w-2xl bg-zinc-950 border border-red-500/40 rounded-3xl shadow-2xl overflow-hidden my-2 sm:my-4 flex flex-col max-h-[96vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-gradient-to-r from-zinc-950 via-zinc-900 to-red-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-rose-500/50 bg-black shrink-0">
              <img src={OFFICIAL_TOK_LOGO} alt="TOK COIN Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                  PANEL ADMINISTRATIVO MAESTRO
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white uppercase tracking-wider">
                  Admin 3138124943
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Gestión de cuentas, agregar/eliminar saldos, comprobantes de recarga QR y retiros
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                adminLogout();
                onClose();
              }}
              className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-rose-400 transition-colors cursor-pointer"
              title="Salir del Modo Administrador"
            >
              <LogOut className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Global Status Banner */}
        {statusMsg && (
          <div
            className={`mx-5 mt-3 p-3 rounded-xl border text-xs flex items-center gap-2 animate-fadeIn ${
              statusMsg.type === 'success'
                ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300'
                : 'bg-rose-950/60 border-rose-500 text-rose-300'
            }`}
          >
            {statusMsg.type === 'success' ? (
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-5 pt-3 border-b border-zinc-800/80 bg-zinc-900/40 overflow-x-auto text-xs font-bold">
          {[
            { id: 'users', label: `Cuentas (${allUsersList.length})`, icon: Users },
            {
              id: 'recharges',
              label: `Comprobantes QR (${pendingRecharges.length} pend.)`,
              icon: ArrowDownLeft,
              badge: pendingRecharges.length,
            },
            {
              id: 'withdrawals',
              label: `Retiros (${pendingWithdrawals.length} pend.)`,
              icon: ArrowUpRight,
              badge: pendingWithdrawals.length,
            },
            { id: 'referrals', label: `Comisiones 10% (${commissionTransactions.length})`, icon: TrendingUp },
            { id: 'settings', label: 'Empresa & Canales', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2.5 px-3.5 rounded-t-xl transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-zinc-950 text-white border-t-2 border-x border-zinc-800 border-t-rose-500 shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900/80'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center font-bold">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Content Panes */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1 text-xs">
          {/* TAB 1: USERS MANAGEMENT */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800">
                <div>
                  <h4 className="text-sm font-bold text-white">Información de Cuentas Registradas</h4>
                  <p className="text-zinc-400 text-xs">
                    El botón para eliminar cada cuenta está enfrente de la información. También puedes agregar o deducir saldo.
                  </p>
                </div>
                {/* Botón para cargar saldo a todas las cuentas automáticamente */}
                <button
                  onClick={() => setShowBulkModal(true)}
                  className="py-2.5 px-4 rounded-xl tok-gradient-red text-white font-bold text-xs tracking-wide shadow-lg hover:opacity-95 transition-all flex items-center gap-1.5 cursor-pointer tok-glow-red shrink-0"
                >
                  <Coins className="w-4 h-4" /> Cargar Saldo a Todas las Cuentas
                </button>
              </div>

              {/* Search Bar */}
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Buscar cuenta por número de 10 dígitos o nombre..."
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs placeholder-zinc-500 focus:border-rose-500 outline-none"
                />
                {userSearch && (
                  <button
                    onClick={() => setUserSearch('')}
                    className="px-3 py-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white text-xs cursor-pointer"
                  >
                    Limpiar
                  </button>
                )}
              </div>

              {/* Mobile-first Vertical Account Cards List (Lista hacia abajo) */}
              <div className="flex flex-col gap-3">
                {filteredUsers.length === 0 ? (
                  <div className="p-8 text-center bg-zinc-950 border border-zinc-800 rounded-2xl text-zinc-500">
                    No se encontraron cuentas que coincidan con la búsqueda.
                  </div>
                ) : (
                  filteredUsers.map((user) => (
                    <div
                      key={user.accountId}
                      className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3 shadow-md hover:border-zinc-700 transition-colors"
                    >
                      {/* Top Header of Card: Prominent Red Delete Button In Front, and VIP Badge */}
                      <div className="flex items-center justify-between gap-2 border-b border-zinc-900 pb-2.5">
                        <button
                          type="button"
                          onClick={() => handleDeleteUser(user.accountId)}
                          className="py-1.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md active:scale-95"
                          title={`Eliminar permanentemente la cuenta ${user.accountId}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Eliminar Cuenta</span>
                        </button>

                        <div className="flex items-center gap-1.5 flex-wrap justify-end">
                          <span className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-950/80 text-rose-300 border border-rose-500/30">
                            {user.currentVipId}
                          </span>
                        </div>
                      </div>

                      {/* Account Details */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-zinc-500 block">Cuenta (10 dígitos):</span>
                          <h3 className="font-mono text-base font-black text-white">{user.accountId}</h3>
                          <p className="text-xs text-zinc-300 font-semibold">{user.fullName || 'Sin nombre registrado'}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-zinc-500 block">Referido</span>
                          <span className="font-mono text-xs text-zinc-400">{user.referralCode}</span>
                          {user.referredBy && (
                            <span className="block text-[10px] text-zinc-500">Por: {user.referredBy}</span>
                          )}
                        </div>
                      </div>

                      {/* Balances Grid: Saldo Retirable vs Ganancias VIP */}
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="p-2.5 rounded-xl bg-zinc-900/80 border border-emerald-950/80">
                          <span className="text-[10px] uppercase font-bold text-emerald-400 block">Saldo Retirable:</span>
                          <span className="font-mono font-black text-emerald-400 text-sm">{formatCOP(user.saldoCop)} COP</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-zinc-900/80 border border-amber-950/80">
                          <span className="text-[10px] uppercase font-bold text-amber-300 block">Ganancias (VIP):</span>
                          <span className="font-mono font-bold text-amber-300 text-sm">{formatCOP(user.gananciasCop)} COP</span>
                        </div>
                      </div>

                      {/* Actions Grid */}
                      <div className="grid grid-cols-3 gap-2 pt-1 border-t border-zinc-900">
                        <button
                          type="button"
                          onClick={() => {
                            setAddBalanceTarget(user.accountId);
                            setAddBalanceAmount(10000);
                          }}
                          className="py-2 px-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 font-semibold text-[11px] transition-colors cursor-pointer border border-emerald-800 text-center"
                        >
                          <PlusCircle className="w-3.5 h-3.5 inline mr-1" /> + Saldo
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setRemoveBalanceTarget(user.accountId);
                            setRemoveBalanceAmount(5000);
                          }}
                          className="py-2 px-2 rounded-xl bg-amber-950 hover:bg-amber-900 text-amber-300 font-semibold text-[11px] transition-colors cursor-pointer border border-amber-800 text-center"
                        >
                          <MinusCircle className="w-3.5 h-3.5 inline mr-1" /> - Saldo
                        </button>
                        <button
                          type="button"
                          onClick={() => setVipTargetAccount(user.accountId)}
                          className="py-2 px-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-rose-300 font-semibold text-[11px] transition-colors cursor-pointer border border-zinc-700 text-center"
                        >
                          <Crown className="w-3.5 h-3.5 inline mr-1" /> VIP
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 2: RECHARGE VOUCHERS */}
          {activeTab === 'recharges' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">Comprobantes de Pago de Recargas (QR)</h4>
                  <p className="text-zinc-400 text-xs">
                    Comprobantes subidos por los usuarios desde su galería al escanear los códigos QR. Al aprobar, se acredita el saldo y se liquida automáticamente el 10% de comisión.
                  </p>
                </div>
              </div>

              {pendingRecharges.length === 0 ? (
                <div className="p-8 text-center bg-zinc-950 border border-zinc-800 rounded-2xl space-y-1">
                  <Check className="w-8 h-8 text-emerald-400 mx-auto" />
                  <p className="text-sm font-bold text-white">No hay comprobantes pendientes</p>
                  <p className="text-zinc-500 text-xs">Todas las solicitudes de recarga han sido revisadas.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pendingRecharges.map((tx) => (
                    <div
                      key={tx.id}
                      className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3 shadow-lg"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-zinc-500 font-mono">Ref: {tx.reference}</span>
                          <h4 className="text-sm font-bold text-white">
                            Cuenta: {tx.userAccountId} ({tx.userFullName})
                          </h4>
                          <p className="text-xs text-zinc-400">Canal: {tx.method}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-base font-extrabold text-emerald-400 font-mono block">
                            {formatCOP(tx.amount)} COP
                          </span>
                          <span className="text-[10px] text-zinc-500">{tx.dateStr}</span>
                        </div>
                      </div>

                      {/* Receipt Preview */}
                      {tx.receiptImageUrl && (
                        <div className="relative aspect-video rounded-xl overflow-hidden border border-zinc-700 bg-black group">
                          <img
                            src={tx.receiptImageUrl}
                            alt="Comprobante cargado por usuario"
                            className="w-full h-full object-contain cursor-pointer"
                            onClick={() => setSelectedReceiptImage(tx.receiptImageUrl!)}
                          />
                          <button
                            type="button"
                            onClick={() => setSelectedReceiptImage(tx.receiptImageUrl!)}
                            className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/80 text-white text-[10px] font-bold flex items-center gap-1 border border-white/20"
                          >
                            <Eye className="w-3 h-3" /> Ver Comprobante Completo
                          </button>
                        </div>
                      )}

                      {/* Approval Buttons */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800">
                        <button
                          onClick={() => {
                            const res = adminApproveRecharge(tx.id);
                            showToast(res.success ? 'success' : 'error', res.message);
                          }}
                          className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md"
                        >
                          <Check className="w-4 h-4" /> Aceptar (+10% Comisión)
                        </button>
                        <button
                          onClick={() => {
                            const note = prompt('Motivo del rechazo:', 'Comprobante no válido o pago no recibido');
                            if (note !== null) {
                              const res = adminRejectRecharge(tx.id, note);
                              showToast('success', res.message);
                            }
                          }}
                          className="py-2.5 px-3 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-rose-800"
                        >
                          <Ban className="w-4 h-4" /> Rechazar
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: WITHDRAWAL MANAGEMENT (Full details matching user's withdrawal request) */}
          {activeTab === 'withdrawals' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800">
                <div>
                  <h4 className="text-sm font-bold text-white">Apartado Oficial de Retiros Solicitados</h4>
                  <p className="text-zinc-400 text-xs">
                    Muestra exactamente la información del apartado de retiro (usuario, banco, titular, cuenta, comisión 15% y neto a transferir).
                  </p>
                </div>
                {/* Filter toggle */}
                <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs">
                  <button
                    onClick={() => setWithdrawalFilter('pendientes')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      withdrawalFilter === 'pendientes'
                        ? 'bg-rose-600 text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Pendientes ({pendingWithdrawals.length})
                  </button>
                  <button
                    onClick={() => setWithdrawalFilter('todos')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      withdrawalFilter === 'todos'
                        ? 'bg-zinc-800 text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Todos ({allWithdrawals.length})
                  </button>
                </div>
              </div>

              {displayedWithdrawals.length === 0 ? (
                <div className="p-8 text-center bg-zinc-950 border border-zinc-800 rounded-2xl space-y-1">
                  <Check className="w-8 h-8 text-emerald-400 mx-auto" />
                  <p className="text-sm font-bold text-white">
                    {withdrawalFilter === 'pendientes'
                      ? 'No hay solicitudes de retiro pendientes por procesar'
                      : 'No hay retiros registrados aún'}
                  </p>
                  <p className="text-zinc-500 text-xs">
                    {withdrawalFilter === 'pendientes'
                      ? 'Cuando los usuarios soliciten retiros de jueves a domingo, aparecerán detallados aquí.'
                      : 'Las solicitudes aparecerán en cuanto los usuarios las emitan.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {displayedWithdrawals.map((tx) => {
                    const gross = Math.abs(tx.amount);
                    const fee = tx.fee !== undefined ? tx.fee : Math.round(gross * 0.15);
                    const net = tx.netAmount !== undefined ? tx.netAmount : gross - fee;

                    return (
                      <div
                        key={tx.id}
                        className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4 shadow-xl hover:border-zinc-700 transition-colors"
                      >
                        {/* High-visibility Callout: "usuario tal está retirando al nombre banco tal con la cuenta tal así exactamente" */}
                        <div className="p-4 rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-red-950/40 border border-rose-500/30 flex flex-col md:flex-row md:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <span className="text-[10px] uppercase tracking-wider font-extrabold text-rose-400 block">
                              DETALLE DE RETIRO SOLICITADO
                            </span>
                            <p className="text-sm sm:text-base font-extrabold text-white leading-snug">
                              Usuario <span className="font-mono text-amber-300 font-black">{tx.userAccountId}</span>{' '}
                              ({tx.userFullName || 'Titular'}) está retirando al banco{' '}
                              <span className="text-emerald-400 font-black">{tx.method}</span> con la cuenta{' '}
                              <span className="font-mono text-emerald-300 font-black">{tx.destinationAccount}</span>
                            </p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                                tx.status === 'pendiente'
                                  ? 'bg-amber-950/80 border border-amber-500 text-amber-300'
                                  : tx.status === 'completado'
                                  ? 'bg-emerald-950/80 border border-emerald-500 text-emerald-300'
                                  : 'bg-rose-950/80 border border-rose-500 text-rose-300'
                              }`}
                            >
                              {tx.status === 'pendiente' ? '⏳ Pendiente' : tx.status === 'completado' ? '✓ Transferido' : '✗ Rechazado'}
                            </span>
                          </div>
                        </div>

                        {/* Exact fields from the user's withdrawal form */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                          <div className="p-3 rounded-xl bg-zinc-900/70 border border-zinc-800">
                            <span className="text-zinc-500 text-[10px] uppercase font-bold block mb-0.5">
                              Cuenta del Usuario (TOK):
                            </span>
                            <span className="font-mono font-bold text-white text-sm">{tx.userAccountId}</span>
                          </div>

                          <div className="p-3 rounded-xl bg-zinc-900/70 border border-zinc-800">
                            <span className="text-zinc-500 text-[10px] uppercase font-bold block mb-0.5">
                              Nombre Completo del Titular:
                            </span>
                            <span className="font-bold text-white text-sm truncate block">
                              {tx.userFullName || 'No registrado'}
                            </span>
                          </div>

                          <div className="p-3 rounded-xl bg-zinc-900/70 border border-zinc-800">
                            <span className="text-zinc-500 text-[10px] uppercase font-bold block mb-0.5">
                              Banco / Billetera Destino:
                            </span>
                            <span className="font-bold text-emerald-400 text-sm">{tx.method}</span>
                          </div>

                          <div className="p-3 rounded-xl bg-zinc-900/70 border border-zinc-800">
                            <span className="text-zinc-500 text-[10px] uppercase font-bold block mb-0.5">
                              Número de Cuenta o Teléfono:
                            </span>
                            <span className="font-mono font-bold text-white text-sm">{tx.destinationAccount}</span>
                          </div>
                        </div>

                        {/* Desglose de Liquidación Obligatorio (Same as withdrawal modal) */}
                        <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2 text-xs">
                          <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">
                            Liquidación Financiera:
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex flex-col justify-between">
                              <span className="text-zinc-400 text-[11px]">Importe Solicitado (Bruto):</span>
                              <span className="font-mono font-bold text-white text-base sm:text-lg">
                                {formatCOP(gross)} COP
                              </span>
                            </div>
                            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex flex-col justify-between">
                              <span className="text-rose-400 text-[11px] font-semibold">Comisión de Retiro (15%):</span>
                              <span className="font-mono font-bold text-rose-400 text-base sm:text-lg">
                                -{formatCOP(fee)} COP
                              </span>
                            </div>
                            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex flex-col justify-between">
                              <span className="text-emerald-300 text-[11px] font-bold">
                                Importe Neto a Transferir al Titular:
                              </span>
                              <span className="font-mono font-black text-emerald-400 text-base sm:text-lg">
                                {formatCOP(net)} COP
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-between text-[11px] text-zinc-500 pt-2 border-t border-zinc-800/80">
                            <span>
                              Referencia: <strong className="font-mono text-zinc-400">{tx.reference}</strong>
                            </span>
                            <span>
                              Fecha de Solicitud: <strong className="text-zinc-400">{tx.dateStr}</strong>
                            </span>
                            {tx.adminNotes && (
                              <span className="text-rose-400 font-semibold">
                                Nota Admin: {tx.adminNotes}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions for Pending Withdrawals */}
                        {tx.status === 'pendiente' && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                            <button
                              onClick={() => {
                                const res = adminApproveWithdrawal(tx.id);
                                showToast('success', res.message);
                              }}
                              className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
                            >
                              <Check className="w-4 h-4" /> Aprobar & Marcar como Transferido ({formatCOP(net)} COP)
                            </button>
                            <button
                              onClick={() => {
                                const note = prompt(
                                  'Motivo del rechazo (se devolverá el saldo al usuario):',
                                  'Cuenta bancaria o titular no coincide'
                                );
                                if (note !== null) {
                                  const res = adminRejectWithdrawal(tx.id, note);
                                  showToast('success', res.message);
                                }
                              }}
                              className="py-3 px-4 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer border border-rose-800"
                            >
                              <Ban className="w-4 h-4" /> Rechazar & Devolver Saldo Reservado
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: REFERRAL COMMISSIONS AUDIT */}
          {activeTab === 'referrals' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800">
                <h4 className="text-sm font-bold text-white">Registro de Comisiones del 10% por Invitaciones</h4>
                <p className="text-zinc-400 text-xs">
                  Comisión automática del 10% calculada sobre cada recarga aprobada y acreditada al Saldo Retirable del invitador.
                </p>
              </div>

              {commissionTransactions.length === 0 ? (
                <p className="text-center py-8 text-zinc-500 text-xs">Aún no se han generado comisiones de red.</p>
              ) : (
                <div className="divide-y divide-zinc-900 border border-zinc-800 rounded-2xl bg-zinc-950 overflow-hidden">
                  {commissionTransactions.map((tx) => (
                    <div key={tx.id} className="p-3.5 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-white">{tx.description}</p>
                        <p className="text-[11px] text-zinc-500">
                          Beneficiario: {tx.userAccountId} ({tx.userFullName}) • Fecha: {tx.dateStr}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-emerald-400 text-sm">
                          +{formatCOP(tx.amount)} COP
                        </span>
                        <span className="block text-[10px] text-zinc-500 uppercase font-semibold">Liquidado</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: COMPANY SETTINGS & DIRECT CHANNELS */}
          {activeTab === 'settings' && (
            <form onSubmit={handleSaveSettings} className="space-y-4 max-w-2xl">
              <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-1">
                <h4 className="text-sm font-bold text-white">Configuración de Canales y Enlaces</h4>
                <p className="text-zinc-400 text-xs">
                  Modifica los enlaces oficiales de WhatsApp y números bancarios.
                </p>
              </div>

              {/* WhatsApp Link */}
              <div>
                <label className="block text-zinc-300 font-semibold mb-1 flex items-center gap-1.5">
                  <MessageCircle className="w-4 h-4 text-emerald-400" /> Enlace Oficial del Grupo de WhatsApp:
                </label>
                <input
                  type="url"
                  required
                  value={localSettings.whatsappGroupUrl}
                  onChange={(e) => setLocalSettings({ ...localSettings, whatsappGroupUrl: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs font-mono focus:border-rose-500 outline-none"
                />
              </div>

              {/* Test mode toggle */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div>
                  <p className="font-bold text-white">Modo Pruebas para Retiros 24/7</p>
                  <p className="text-[11px] text-zinc-400">
                    Permite enviar retiros sin restringir a Jueves-Domingo 1pm-5pm (ideal para probar flujos de pago).
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={localSettings.allowWithdrawalsAnytimeForTesting}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, allowWithdrawalsAnytimeForTesting: e.target.checked })
                  }
                  className="w-5 h-5 accent-rose-600 rounded cursor-pointer"
                />
              </div>

              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl tok-gradient-red text-white font-bold text-xs shadow-lg hover:opacity-95 transition-all cursor-pointer"
              >
                Guardar Ajustes de la Empresa
              </button>
            </form>
          )}
        </div>
      </div>

      {/* MODAL: Fullscreen Image Lightbox for Voucher */}
      {selectedReceiptImage && (
        <div className="fixed inset-0 z-60 bg-black/95 flex flex-col items-center justify-center p-4">
          <button
            onClick={() => setSelectedReceiptImage(null)}
            className="absolute top-4 right-4 p-2 rounded-full bg-zinc-900 text-white hover:bg-zinc-800 cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={selectedReceiptImage}
            alt="Comprobante en detalle"
            className="max-w-[90vw] max-h-[85vh] object-contain rounded-xl border border-zinc-700"
          />
        </div>
      )}

      {/* MODAL: Botón para Cargar Saldo a Todas las Cuentas Automáticamente */}
      {showBulkModal && (
        <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
          <form
            onSubmit={handleBulkSubmit}
            className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-3xl p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Coins className="w-5 h-5 text-rose-500" /> Cargar Saldo a Todas las Cuentas
              </h3>
              <button
                type="button"
                onClick={() => setShowBulkModal(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-400">
              Este importe se acreditará automáticamente en el <strong>"Saldo Retirable"</strong> de las{' '}
              {allUsersList.length} cuentas registradas en el sistema.
            </p>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Monto por cuenta (COP):</label>
              <input
                type="number"
                min="1000"
                step="1000"
                required
                value={bulkAmount}
                onChange={(e) => setBulkAmount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Concepto / Motivo:</label>
              <input
                type="text"
                required
                value={bulkConcept}
                onChange={(e) => setBulkConcept(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-rose-500 outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl tok-gradient-red text-white font-bold text-xs tracking-wide shadow-lg hover:opacity-95 transition-all cursor-pointer"
            >
              Confirmar Abono Masivo a {allUsersList.length} Cuentas
            </button>
          </form>
        </div>
      )}

      {/* MODAL: Botón para Agregar Saldo a Cuenta */}
      {addBalanceTarget && (
        <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
          <form
            onSubmit={handleAddBalanceSubmit}
            className="w-full max-w-md bg-zinc-950 border border-emerald-500/40 rounded-3xl p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-emerald-400" /> Agregar Saldo a Cuenta {addBalanceTarget}
              </h3>
              <button
                type="button"
                onClick={() => setAddBalanceTarget(null)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Destino del Saldo:</label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setAddBalanceType('saldo')}
                  className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-colors ${
                    addBalanceType === 'saldo'
                      ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300'
                      : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                  }`}
                >
                  Saldo Retirable (VIP 2-5)
                </button>
                <button
                  type="button"
                  onClick={() => setAddBalanceType('ganancias')}
                  className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-colors ${
                    addBalanceType === 'ganancias'
                      ? 'border-amber-500 bg-amber-950/40 text-amber-300'
                      : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                  }`}
                >
                  Ganancias (Compras VIP)
                </button>
              </div>
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Monto a agregar (COP):</label>
              <input
                type="number"
                min="1000"
                step="1000"
                required
                value={addBalanceAmount}
                onChange={(e) => setAddBalanceAmount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Motivo / Concepto:</label>
              <input
                type="text"
                required
                value={addBalanceReason}
                onChange={(e) => setAddBalanceReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-rose-500 outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wide shadow-lg transition-all cursor-pointer"
            >
              Confirmar Agregar Saldo (+{formatCOP(addBalanceAmount)} COP)
            </button>
          </form>
        </div>
      )}

      {/* MODAL: Botón para Eliminar / Deducir Saldo de Cuenta */}
      {removeBalanceTarget && (
        <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
          <form
            onSubmit={handleRemoveBalanceSubmit}
            className="w-full max-w-md bg-zinc-950 border border-amber-500/40 rounded-3xl p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <MinusCircle className="w-5 h-5 text-amber-400" /> Eliminar Saldo de Cuenta {removeBalanceTarget}
              </h3>
              <button
                type="button"
                onClick={() => setRemoveBalanceTarget(null)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Origen del Saldo a Deducir:</label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRemoveBalanceType('saldo')}
                  className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-colors ${
                    removeBalanceType === 'saldo'
                      ? 'border-amber-500 bg-amber-950/40 text-amber-300'
                      : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                  }`}
                >
                  Saldo Retirable
                </button>
                <button
                  type="button"
                  onClick={() => setRemoveBalanceType('ganancias')}
                  className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-colors ${
                    removeBalanceType === 'ganancias'
                      ? 'border-amber-500 bg-amber-950/40 text-amber-300'
                      : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                  }`}
                >
                  Ganancias (VIP)
                </button>
              </div>
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Monto a deducir (COP):</label>
              <input
                type="number"
                min="1000"
                step="1000"
                required
                value={removeBalanceAmount}
                onChange={(e) => setRemoveBalanceAmount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">Motivo:</label>
              <input
                type="text"
                required
                value={removeBalanceReason}
                onChange={(e) => setRemoveBalanceReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-rose-500 outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs tracking-wide shadow-lg transition-all cursor-pointer"
            >
              Confirmar Deducción de Saldo (-{formatCOP(removeBalanceAmount)} COP)
            </button>
          </form>
        </div>
      )}

      {/* MODAL: Activar Nivel VIP Manualmente */}
      {vipTargetAccount && (
        <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
          <form
            onSubmit={handleVipSubmit}
            className="w-full max-w-md bg-zinc-950 border border-rose-500/40 rounded-3xl p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Crown className="w-5 h-5 text-rose-500" /> Activar Nivel VIP Manualmente
              </h3>
              <button
                type="button"
                onClick={() => setVipTargetAccount(null)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-400">
              Activa cualquier nivel VIP en la cuenta <strong>{vipTargetAccount}</strong> sin costo para el usuario.
            </p>
            <div className="space-y-2">
              {Object.values(vipConfig).map((lvl) => (
                <label
                  key={lvl.id}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                    selectedVipId === lvl.id
                      ? 'border-rose-500 bg-rose-950/40 text-white'
                      : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="vipSelect"
                      value={lvl.id}
                      checked={selectedVipId === lvl.id}
                      onChange={() => setSelectedVipId(lvl.id)}
                      className="accent-rose-500"
                    />
                    <span className="font-bold text-xs">{lvl.name}</span>
                  </div>
                  <span className="font-mono text-xs">{lvl.durationDays} días</span>
                </label>
              ))}
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl tok-gradient-red text-white font-bold text-xs tracking-wide shadow-lg hover:opacity-95 transition-all cursor-pointer"
            >
              Activar Membresía en Cuenta {vipTargetAccount}
            </button>
          </form>
        </div>
      )}

      {/* MODAL DE CONFIRMACIÓN PARA ELIMINAR CUENTA (Reemplazo infalible de window.confirm) */}
      {accountToDelete && (
        <div className="fixed inset-0 z-70 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-sm bg-zinc-950 border border-rose-600 rounded-3xl p-6 space-y-4 shadow-2xl text-center">
            <div className="w-14 h-14 rounded-full bg-rose-950/80 border border-rose-500/60 flex items-center justify-center mx-auto text-rose-400">
              <Trash2 className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-black text-white">¿Eliminar esta cuenta definitivamente?</h3>
              <p className="text-xs text-zinc-300">
                Se eliminará permanentemente la cuenta <strong className="font-mono text-rose-400 text-sm">{accountToDelete}</strong> y todo su historial de saldo, recargas y retiros.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setAccountToDelete(null)}
                className="py-2.5 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-300 font-bold text-xs hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const target = accountToDelete;
                  setAccountToDelete(null);
                  const res = adminDeleteUser(target);
                  showToast(res.success ? 'success' : 'error', res.message);
                }}
                className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg transition-colors cursor-pointer"
              >
                Sí, Eliminar Cuenta
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
