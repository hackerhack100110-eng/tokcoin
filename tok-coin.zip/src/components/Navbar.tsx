import React from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO } from '../config/vipConfig';
import {
  Home,
  CheckSquare,
  Crown,
  Wallet,
  Users,
  Box,
  LogOut,
  ShieldAlert,
  ArrowDownLeft,
  ArrowUpRight,
  MessageCircle,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  onOpenRecharge: () => void;
  onOpenWithdraw: () => void;
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  onOpenRecharge,
  onOpenWithdraw,
  onOpenAdmin,
}) => {
  const { currentUser, logout, getVipStatus, isAdminLoggedIn, companySettings } = useAuth();
  const vipStatus = getVipStatus();

  return (
    <>
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800/80 px-3 sm:px-6 lg:px-8 py-2.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
          {/* Official Brand Logo & Name */}
          <div
            onClick={() => onTabChange('home')}
            className="flex items-center gap-3 cursor-pointer select-none group shrink-0"
          >
            <div className="w-10 h-10 rounded-2xl overflow-hidden border-2 border-red-500/50 bg-black shadow-lg shadow-rose-950/50 group-hover:scale-105 transition-transform">
              <img
                src={OFFICIAL_TOK_LOGO}
                alt="TOK COIN Logo"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-white text-base tracking-tight">
                  TOK <span className="text-rose-500">COIN</span>
                </span>
                <span className="text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-rose-600/20 text-rose-400 border border-rose-500/30">
                  OFICIAL
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 hidden sm:block">Plataforma de Tareas y Recompensas COP</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-zinc-900/60 p-1 rounded-xl border border-zinc-800">
            {[
              { id: 'home', label: 'Inicio', icon: Home },
              { id: 'tasks', label: 'Tareas Diarias', icon: CheckSquare },
              { id: 'vip', label: 'Niveles VIP', icon: Crown },
              { id: 'wallet', label: 'Mi Cuenta', icon: Wallet },
              { id: 'referral', label: 'Invitaciones', icon: Users },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                    isActive
                      ? 'bg-rose-600 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right User Bar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {currentUser ? (
              <>
                {/* Two Balances Indicator */}
                <div className="hidden sm:flex items-center gap-2">
                  {/* Saldo Retirable */}
                  <div
                    onClick={onOpenWithdraw}
                    className="px-2.5 py-1 rounded-xl bg-zinc-900 border border-emerald-500/30 text-left cursor-pointer hover:border-emerald-500 transition-colors"
                    title="Saldo obtenido en VIP 2-5 y comisiones (SÍ se puede retirar)"
                  >
                    <span className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold block">
                      Saldo Retirable
                    </span>
                    <span className="text-xs font-black text-emerald-400 font-mono">
                      {formatCOP(currentUser.saldoCop)}
                    </span>
                  </div>

                  {/* Ganancias VIP */}
                  <div
                    onClick={onOpenRecharge}
                    className="px-2.5 py-1 rounded-xl bg-zinc-900 border border-zinc-700/80 text-left cursor-pointer hover:border-rose-500 transition-colors"
                    title="Ganancias VIP 1 y recargas QR (solo para comprar VIP, no retirable)"
                  >
                    <span className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold block">
                      Ganancias (VIP)
                    </span>
                    <span className="text-xs font-black text-white font-mono">
                      {formatCOP(currentUser.gananciasCop)}
                    </span>
                  </div>
                </div>

                {/* Mobile combined pill */}
                <button
                  onClick={onOpenWithdraw}
                  className="sm:hidden px-2 py-1 rounded-xl bg-zinc-900 border border-emerald-500/30 text-left cursor-pointer"
                >
                  <span className="text-[8px] uppercase tracking-wider text-zinc-400 font-bold block">
                    Saldo Retirable
                  </span>
                  <span className="text-xs font-extrabold text-emerald-400 font-mono">
                    {formatCOP(currentUser.saldoCop)}
                  </span>
                </button>

                {/* WhatsApp Community Shortcut */}
                <a
                  href={companySettings.whatsappGroupUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-900/50 transition-colors cursor-pointer flex items-center justify-center"
                  title="Grupo Oficial de WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>

                {/* Logout: Salir para regresar al apartado de registro */}
                <button
                  onClick={logout}
                  className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-rose-400 hover:border-rose-900/50 transition-colors cursor-pointer flex items-center justify-center"
                  title="Salir al registro / inicio"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : null}
          </div>
        </div>
      </header>

      {/* Bottom Navigation for Mobile Devices */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 backdrop-blur-lg border-t border-zinc-800/80 px-2 py-2 flex items-center justify-around">
        {[
          { id: 'home', label: 'Inicio', icon: Home },
          { id: 'tasks', label: 'Tareas', icon: CheckSquare },
          { id: 'vip', label: 'VIP', icon: Crown },
          { id: 'wallet', label: 'Cuenta', icon: Wallet },
          { id: 'referral', label: 'Equipo', icon: Users },
        ].map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                isActive ? 'text-rose-500 scale-105 font-bold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.5]' : ''}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
