import React, { useState } from 'react';
import { useAuth, ADMIN_USERNAME, ADMIN_PASSWORD } from '../context/AuthContext';
import { OFFICIAL_TOK_LOGO } from '../config/vipConfig';
import {
  Shield,
  Key,
  Smartphone,
  Gift,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  ShieldAlert,
  Lock,
  UserCheck,
  MessageCircle,
  X,
} from 'lucide-react';

interface AuthViewProps {
  onOpenAdminDirectly?: () => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ onOpenAdminDirectly }) => {
  const { login, register, adminLogin, isAdminLoggedIn, companySettings } = useAuth();
  // Primary section is registering a new account as requested
  const [isRegister, setIsRegister] = useState(true);
  const [accountId, setAccountId] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Semi-hidden Admin Access Modal State (Button top-right)
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [adminUserInput, setAdminUserInput] = useState('');
  const [adminPassInput, setAdminPassInput] = useState('');
  const [adminError, setAdminError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    // Validate account (any 10 numeric digits, no mandatory 0 prefix)
    if (!/^\d{10}$/.test(accountId.trim())) {
      setErrorMsg('El número de cuenta debe tener exactamente 10 dígitos numéricos (ej: 3109876543).');
      return;
    }

    // Validate password (6 to 10 digits)
    if (!/^\d{6,10}$/.test(password.trim())) {
      setErrorMsg('La contraseña debe tener de 6 a 10 dígitos numéricos.');
      return;
    }

    if (isRegister) {
      const res = register(
        accountId.trim(),
        password.trim(),
        referralCode.trim() || undefined,
        fullName.trim() || undefined
      );
      if (res.success) {
        setSuccessMsg(res.message);
      } else {
        setErrorMsg(res.message);
      }
    } else {
      const res = login(accountId.trim(), password.trim());
      if (!res.success) {
        setErrorMsg(res.message);
      }
    }
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError(null);
    const res = adminLogin(adminUserInput, adminPassInput);
    if (res.success) {
      setShowAdminModal(false);
      if (onOpenAdminDirectly) onOpenAdminDirectly();
    } else {
      setAdminError(res.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#060608] flex flex-col items-center justify-center p-4 relative overflow-hidden select-none">
      {/* Semi-hidden button in the top right corner as instructed */}
      <div className="absolute top-4 right-4 z-30">
        <button
          onClick={() => setShowAdminModal(true)}
          className="p-2 rounded-xl bg-zinc-950/40 hover:bg-zinc-900 border border-zinc-800/40 hover:border-red-500/40 text-zinc-600 hover:text-red-400 opacity-60 hover:opacity-100 transition-all cursor-pointer"
          title="Acceso Administrativo Seguro"
        >
          <Lock className="w-4 h-4" />
        </button>
      </div>

      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative z-10 space-y-6 my-6">
        {/* Official Brand Logo Image (Pristine and unedited) */}
        <div className="text-center space-y-3">
          <div className="w-28 h-28 sm:w-32 sm:h-32 mx-auto rounded-3xl overflow-hidden border-2 border-red-500/50 shadow-2xl shadow-rose-950/70 bg-black">
            <img
              src={OFFICIAL_TOK_LOGO}
              alt="TOK COIN Logo Oficial"
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            TOK <span className="text-rose-500">COIN</span>
          </h1>
          <p className="text-xs text-zinc-400 max-w-xs mx-auto">
            Plataforma oficial de micro-tareas de video y recompensas diarias en Colombia (COP)
          </p>
        </div>

        {/* Card Form */}
        <div className="tok-gradient-card border border-zinc-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-5">
          {/* Tab Selector */}
          <div className="grid grid-cols-2 p-1 bg-zinc-900/80 rounded-xl border border-zinc-800 text-xs font-bold">
            <button
              type="button"
              onClick={() => {
                setIsRegister(false);
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-2 rounded-lg transition-all cursor-pointer ${
                !isRegister ? 'bg-rose-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Iniciar Sesión
            </button>
            <button
              type="button"
              onClick={() => {
                setIsRegister(true);
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-2 rounded-lg transition-all cursor-pointer ${
                isRegister ? 'bg-rose-600 text-white shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Registrar Cuenta
            </button>
          </div>

          {/* Feedback messages */}
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2 animate-fadeIn">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Full name if register */}
            {isRegister && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-300">
                  Nombre Completo:
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ej: Carlos Alberto Mendoza"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white text-sm focus:border-rose-500 outline-none"
                />
              </div>
            )}

            {/* Account ID input (10 digits) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-zinc-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-rose-400" /> Cuenta (10 dígitos)
                </span>
                <span className="text-[10px] text-zinc-500">Número telefónico</span>
              </label>
              <input
                type="text"
                maxLength={10}
                required
                value={accountId}
                onChange={(e) => setAccountId(e.target.value.replace(/\D/g, ''))}
                placeholder="Ej: 3109876543"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white font-mono text-sm placeholder:text-zinc-600 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none transition-all"
              />
            </div>

            {/* Password input (6 to 10 digits) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-zinc-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-rose-400" /> Contraseña (6 a 10 dígitos numéricos)
                </span>
                <span className="text-[10px] text-zinc-500">PIN de 6-10 dígitos</span>
              </label>
              <input
                type="password"
                maxLength={10}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value.replace(/\D/g, ''))}
                placeholder="••••••"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white font-mono text-sm placeholder:text-zinc-600 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none transition-all tracking-widest"
              />
            </div>

            {/* Referral code (Optional on Register) */}
            {isRegister && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-300 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Gift className="w-3.5 h-3.5 text-rose-400" /> Código de Invitación (Opcional)
                  </span>
                  <span className="text-[10px] text-emerald-400">Opcional</span>
                </label>
                <input
                  type="text"
                  maxLength={12}
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                  placeholder="Ej: TOK-GOLD01"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white font-mono text-sm placeholder:text-zinc-600 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 outline-none transition-all uppercase"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 rounded-xl tok-gradient-red text-white font-bold text-sm tracking-wide shadow-lg hover:opacity-95 transition-all cursor-pointer tok-glow-red flex items-center justify-center gap-2"
            >
              {isRegister ? 'Completar Registro' : 'Entrar a TOK COIN'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* WhatsApp Official Community Link */}
        <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-zinc-800 text-center space-y-2">
          <p className="text-xs text-zinc-400">¿Tienes dudas o necesitas soporte oficial?</p>
          <a
            href={companySettings.whatsappGroupUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" /> Unirse al Grupo Oficial de WhatsApp
          </a>
        </div>

        {/* Security Footer */}
        <div className="flex items-center justify-center gap-4 text-xs text-zinc-500">
          <span className="flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-zinc-400" /> Datos Cifrados
          </span>
          <span>•</span>
          <span>Validación Servidor Colombia</span>
          <span>•</span>
          <span>Red TOK COP</span>
        </div>
      </div>

      {/* MODAL: Semi-hidden Master Admin Login */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={handleAdminSubmit}
            className="w-full max-w-sm bg-zinc-950 border border-red-500/50 rounded-3xl p-6 space-y-4 shadow-2xl relative"
          >
            <button
              type="button"
              onClick={() => setShowAdminModal(false)}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-600/20 border border-rose-500/40 text-rose-500">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-white text-base">Acceso Master Administrativo</h3>
                <p className="text-zinc-400 text-xs">Ingreso exclusivo para gestión empresarial</p>
              </div>
            </div>

            {adminError && (
              <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/50 text-rose-300 text-xs">
                {adminError}
              </div>
            )}

            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">
                Usuario Único Administrativo:
              </label>
              <input
                type="text"
                required
                value={adminUserInput}
                onChange={(e) => setAdminUserInput(e.target.value)}
                placeholder="Usuario maestro"
                className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-zinc-400 text-xs font-semibold mb-1">
                Contraseña Única Administrativa:
              </label>
              <input
                type="password"
                required
                value={adminPassInput}
                onChange={(e) => setAdminPassInput(e.target.value)}
                placeholder="Contraseña maestra"
                className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-sm focus:border-rose-500 outline-none tracking-wider"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl tok-gradient-red text-white font-bold text-xs tracking-wide shadow-lg hover:opacity-95 transition-all cursor-pointer tok-glow-red"
            >
              Autenticar Panel Maestro
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
