import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO } from '../config/vipConfig';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Copy,
  Check,
  Crown,
  Gift,
  Coins,
  History,
  MessageCircle,
  ShieldCheck,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';

interface WalletViewProps {
  onOpenRecharge: () => void;
  onOpenWithdraw: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ onOpenRecharge, onOpenWithdraw }) => {
  const { currentUser, getVipStatus, companySettings, allTransactions } = useAuth();
  const vipStatus = getVipStatus();
  const [copiedAccount, setCopiedAccount] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);

  if (!currentUser) return null;

  const handleCopyAccount = () => {
    navigator.clipboard.writeText(currentUser.accountId);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const handleCopyRef = () => {
    navigator.clipboard.writeText(currentUser.referralCode);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  const userTransactions = allTransactions.filter(
    (t) => t.userId === currentUser.id || t.userAccountId === currentUser.accountId
  );

  return (
    <div className="space-y-6 pb-20">
      {/* Account Info Profile Header */}
      <div className="p-6 sm:p-8 rounded-3xl tok-gradient-card border border-zinc-800 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-red-500/60 shadow-xl bg-black shrink-0">
              <img
                src={OFFICIAL_TOK_LOGO}
                alt="Logo TOK COIN"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white">{currentUser.fullName || 'Usuario TOK'}</h1>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${vipStatus.level.badgeColor}`}>
                  {vipStatus.level.name}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-400">
                <span className="flex items-center gap-1">
                  Cuenta: <strong className="font-mono text-white">{currentUser.accountId}</strong>
                  <button onClick={handleCopyAccount} className="hover:text-white cursor-pointer ml-0.5">
                    {copiedAccount ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  Código: <strong className="font-mono text-rose-400 font-bold">{currentUser.referralCode}</strong>
                  <button onClick={handleCopyRef} className="hover:text-white cursor-pointer ml-0.5">
                    {copiedRef ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </span>
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={onOpenRecharge}
              className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl tok-gradient-red text-white font-bold text-xs tracking-wide shadow-md hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer tok-glow-red"
            >
              <ArrowDownLeft className="w-4 h-4" /> Recargar QR
            </button>
            <button
              onClick={onOpenWithdraw}
              className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold text-xs tracking-wide transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <ArrowUpRight className="w-4 h-4 text-emerald-400" /> Retirar COP
            </button>
          </div>
        </div>

        {/* The Two Balances Requested: "Saldo" vs "Ganancias" */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8 pt-6 border-t border-zinc-800/80">
          {/* Card: Saldo (Retirable) */}
          <div
            onClick={onOpenWithdraw}
            className="p-4 rounded-2xl bg-zinc-900/90 border border-emerald-500/40 hover:border-emerald-500 transition-all cursor-pointer space-y-2 group relative overflow-hidden"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] uppercase font-bold text-emerald-400 tracking-wider flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-emerald-400" /> Saldo Retirable
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950/60 text-emerald-400 border border-emerald-500/40">
                100% RETIRABLE
              </span>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
              {formatCOP(currentUser.saldoCop)} <span className="text-xs text-zinc-500">COP</span>
            </p>
            <p className="text-[11px] text-zinc-400 leading-tight">
              Generado a partir de tareas de <strong>VIP 2 a VIP 5</strong>, comisiones de invitaciones del 10% y abonos administrativos.
            </p>
          </div>

          {/* Card: Ganancias (No Retirable / Compras VIP) */}
          <div
            onClick={onOpenRecharge}
            className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 hover:border-rose-500/60 transition-all cursor-pointer space-y-2 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] uppercase font-bold text-rose-400 tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-rose-500" /> Ganancias (Compras VIP)
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800 text-zinc-400 border border-zinc-700">
                NO RETIRABLE
              </span>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
              {formatCOP(currentUser.gananciasCop)} <span className="text-xs text-zinc-500">COP</span>
            </p>
            <p className="text-[11px] text-zinc-400 leading-tight">
              Ganancias acumuladas del <strong>VIP 1 Gratuito</strong> y saldo cargado mediante comprobante QR. Sirve exclusivamente para adquirir membresías VIP.
            </p>
          </div>

          {/* Card: Comisiones de Referidos */}
          <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2 sm:col-span-2 lg:col-span-1">
            <div className="flex items-center justify-between">
              <span className="text-[11px] uppercase font-bold text-amber-400 tracking-wider flex items-center gap-1.5">
                <Gift className="w-4 h-4 text-amber-400" /> Comisiones de Red (10%)
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/60 text-amber-300 border border-amber-500/30">
                ACREDITADO
              </span>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
              {formatCOP(currentUser.totalCommissionsCop || 0)} <span className="text-xs text-zinc-500">COP</span>
            </p>
            <p className="text-[11px] text-zinc-400 leading-tight">
              10% automático sobre cada recarga aprobada de tus usuarios invitados directos.
            </p>
          </div>
        </div>
      </div>

      {/* Official Community Channel */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-zinc-900 to-zinc-950 border border-emerald-500/30 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Comunidad Oficial de WhatsApp</h3>
          </div>
          <p className="text-xs text-zinc-400">
            Noticias, comprobantes de pago de la comunidad y soporte directo oficial de TOK COIN.
          </p>
        </div>
        <a
          href={companySettings.whatsappGroupUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wide shadow-md transition-all shrink-0 flex items-center gap-2 cursor-pointer"
        >
          Unirme al Grupo de WhatsApp <MessageCircle className="w-4 h-4" />
        </a>
      </div>

      {/* Complete Movement History Log */}
      <div className="rounded-3xl bg-zinc-950 border border-zinc-800 p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-rose-500" />
            <h3 className="text-base font-bold text-white">Historial de Movimientos de la Cuenta</h3>
          </div>
          <span className="text-xs text-zinc-400 font-mono">
            {userTransactions.length} registros
          </span>
        </div>

        {userTransactions.length === 0 ? (
          <p className="text-xs text-zinc-500 py-6 text-center">No hay transacciones registradas todavía.</p>
        ) : (
          <div className="divide-y divide-zinc-900">
            {userTransactions.map((tx) => (
              <div key={tx.id} className="py-3.5 flex items-center justify-between text-xs gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      tx.amount >= 0
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}
                  >
                    {tx.amount >= 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div className="space-y-0.5">
                    <p className="font-bold text-white text-sm">{tx.description}</p>
                    <p className="text-[11px] text-zinc-400">
                      Fecha: {tx.dateStr} • {tx.method || 'TOK Sistema'}
                      {tx.reference ? ` • Ref: ${tx.reference}` : ''}
                      {tx.fee ? ` • Comisión 15%: -${formatCOP(tx.fee)}` : ''}
                      {tx.adminNotes ? ` • Nota: ${tx.adminNotes}` : ''}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span
                    className={`font-mono text-sm font-extrabold block ${
                      tx.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {tx.amount >= 0 ? '+' : ''}
                    {formatCOP(tx.amount)} COP
                  </span>
                  <span
                    className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full inline-block mt-0.5 ${
                      tx.status === 'completado'
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                        : tx.status === 'pendiente'
                        ? 'bg-amber-950/60 text-amber-400 border border-amber-500/30 animate-pulse'
                        : 'bg-rose-950/60 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
