import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, VipLevel, CompletedTaskRecord, Transaction, TaskItem, CompanySettings } from '../types';
import {
  loadVipConfig,
  saveVipConfig,
  resetVipConfig,
  DEFAULT_VIP_LEVELS,
  loadCompanySettings,
  saveCompanySettings,
  checkWithdrawalSchedule,
} from '../config/vipConfig';

interface AuthContextType {
  currentUser: User | null;
  vipConfig: Record<string, VipLevel>;
  companySettings: CompanySettings;
  currentDateStr: string;
  isAdminLoggedIn: boolean;
  adminLogin: (user: string, pass: string) => { success: boolean; message: string };
  adminLogout: () => void;
  login: (accountId: string, password: string) => { success: boolean; message: string };
  register: (accountId: string, password: string, referralCode?: string, fullName?: string) => { success: boolean; message: string };
  logout: () => void;
  completeTask: (task: TaskItem, forVipId?: string) => { success: boolean; reward: number; message: string };
  purchaseVip: (vipId: string) => { success: boolean; message: string };
  requestRecharge: (amount: number, method: string, receiptImageUrl: string) => { success: boolean; message: string };
  requestWithdrawal: (
    amount: number,
    destinationAccount: string,
    fullName: string,
    passwordAttempt: string,
    bankMethod: string
  ) => { success: boolean; message: string; fee?: number; netAmount?: number };
  // Admin Operations
  adminApproveRecharge: (transactionId: string) => { success: boolean; message: string };
  adminRejectRecharge: (transactionId: string, notes?: string) => { success: boolean; message: string };
  adminApproveWithdrawal: (transactionId: string) => { success: boolean; message: string };
  adminRejectWithdrawal: (transactionId: string, notes?: string) => { success: boolean; message: string };
  adminBulkCreditAllUsers: (amount: number, concept: string) => { success: boolean; message: string; affectedCount: number };
  adminAdjustUserBalance: (
    accountId: string,
    saldoDelta: number,
    gananciasDelta: number,
    reason: string
  ) => { success: boolean; message: string };
  adminAddUserBalance: (
    accountId: string,
    balanceType: 'saldo' | 'ganancias',
    amount: number,
    reason: string
  ) => { success: boolean; message: string };
  adminRemoveUserBalance: (
    accountId: string,
    balanceType: 'saldo' | 'ganancias',
    amount: number,
    reason: string
  ) => { success: boolean; message: string };
  adminManualActivateVip: (accountId: string, vipId: string) => { success: boolean; message: string };
  adminDeleteUser: (accountId: string) => { success: boolean; message: string };
  updateCompanySettings: (settings: CompanySettings) => void;
  updateVipConfig: (newConfig: Record<string, VipLevel>) => void;
  resetAllVipConfig: () => void;
  advanceSimulatedDay: (days?: number) => void;
  getTasksCompletedToday: () => CompletedTaskRecord[];
  getVipStatus: () => {
    level: VipLevel;
    isExpired: boolean;
    daysRemaining: number;
    vip1CapReached: boolean;
    dailyTasksDoneToday: number;
    dailyTasksLimit: number;
    canDoTasks: boolean;
    blockReason?: string;
  };
  getVipStatusForId: (vipId: string) => {
    level: VipLevel;
    isExpired: boolean;
    daysRemaining: number;
    vip1CapReached: boolean;
    dailyTasksDoneToday: number;
    dailyTasksLimit: number;
    canDoTasks: boolean;
    blockReason?: string;
  };
  getUserActiveVips: () => {
    level: VipLevel;
    isExpired: boolean;
    daysRemaining: number;
    vip1CapReached: boolean;
    dailyTasksDoneToday: number;
    dailyTasksLimit: number;
    canDoTasks: boolean;
    blockReason?: string;
  }[];
  allUsersList: User[];
  allTransactions: Transaction[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USERS_STORAGE_KEY = 'tok_coin_users_v3';
const TRANSACTIONS_STORAGE_KEY = 'tok_coin_transactions_v3';
const SESSION_STORAGE_KEY = 'tok_coin_session_account_id_v3';
const ADMIN_SESSION_KEY = 'tok_coin_admin_active_v2';

// Admin credentials as mandated
export const ADMIN_USERNAME = '3138124943';
export const ADMIN_PASSWORD = '6896368081';

function generateReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let res = 'TOK-';
  for (let i = 0; i < 6; i++) {
    res += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return res;
}

function getTodayString(offsetDays = 0): string {
  const d = new Date();
  if (offsetDays !== 0) {
    d.setDate(d.getDate() + offsetDays);
  }
  return d.toISOString().split('T')[0];
}

// Initial demo users with strictly 0 pesos in all balance fields as mandated
const INITIAL_DEMO_USERS: User[] = [
  {
    id: 'usr_demo_1001',
    accountId: '3109876543',
    password: '123456',
    fullName: 'Carlos Mendoza',
    referralCode: 'TOK-GOLD01',
    createdAt: Date.now() - 3600000 * 24,
    gananciasCop: 0,
    saldoCop: 0,
    totalCommissionsCop: 0,
    totalEarnedCop: 0,
    currentVipId: 'vip1',
    activeVips: {
      vip1: {
        vipId: 'vip1',
        activatedAt: Date.now() - 3600000 * 24,
        expiresAt: Date.now() + 86400000 * 2,
      },
    },
    vipActivatedAt: Date.now() - 3600000 * 24,
    vipExpiresAt: Date.now() + 86400000 * 2,
    virtualDateOffsetDays: 0,
    completedTasks: [],
  },
  {
    id: 'usr_demo_1002',
    accountId: '3205558891',
    password: '654321',
    fullName: 'Andrea Gomez',
    referralCode: 'TOK-PRO88',
    referredBy: 'TOK-GOLD01',
    createdAt: Date.now() - 3600000 * 12,
    gananciasCop: 0,
    saldoCop: 0,
    totalCommissionsCop: 0,
    totalEarnedCop: 0,
    currentVipId: 'vip1',
    activeVips: {
      vip1: {
        vipId: 'vip1',
        activatedAt: Date.now() - 3600000 * 12,
        expiresAt: Date.now() + 86400000 * 2,
      },
    },
    vipActivatedAt: Date.now() - 3600000 * 12,
    vipExpiresAt: Date.now() + 86400000 * 2,
    virtualDateOffsetDays: 0,
    completedTasks: [],
  },
];

const INITIAL_TRANSACTIONS: Transaction[] = [];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const raw = localStorage.getItem(USERS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading users DB', e);
    }
    return INITIAL_DEMO_USERS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const raw = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Error loading transactions DB', e);
    }
    return INITIAL_TRANSACTIONS;
  });

  // Default to null so user MUST register or login before entering the app
  const [currentAccountId, setCurrentAccountId] = useState<string | null>(() => {
    return localStorage.getItem(SESSION_STORAGE_KEY) || null;
  });

  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem(ADMIN_SESSION_KEY) === 'true';
  });

  const [vipConfig, setVipConfig] = useState<Record<string, VipLevel>>(() => loadVipConfig());
  const [companySettings, setCompanySettings] = useState<CompanySettings>(() => loadCompanySettings());

  // Save users state
  useEffect(() => {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (e) {
      console.error('Failed to save users', e);
    }
  }, [users]);

  // Save transactions state
  useEffect(() => {
    try {
      localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(transactions));
    } catch (e) {
      console.error('Failed to save transactions', e);
    }
  }, [transactions]);

  // Save sessions
  useEffect(() => {
    if (currentAccountId) {
      localStorage.setItem(SESSION_STORAGE_KEY, currentAccountId);
    } else {
      localStorage.removeItem(SESSION_STORAGE_KEY);
    }
  }, [currentAccountId]);

  useEffect(() => {
    localStorage.setItem(ADMIN_SESSION_KEY, isAdminLoggedIn ? 'true' : 'false');
  }, [isAdminLoggedIn]);

  const currentUser = users.find((u) => u.accountId === currentAccountId) || null;
  const virtualOffset = currentUser?.virtualDateOffsetDays || 0;
  const currentDateStr = getTodayString(virtualOffset);

  // Admin Login
  const adminLogin = (user: string, pass: string) => {
    if (user.trim() === ADMIN_USERNAME && pass.trim() === ADMIN_PASSWORD) {
      setIsAdminLoggedIn(true);
      return { success: true, message: '¡Acceso concedido al Panel Administrativo TOK COIN!' };
    }
    return { success: false, message: 'Usuario o contraseña administrativa incorrectos.' };
  };

  const adminLogout = () => {
    setIsAdminLoggedIn(false);
  };

  // User Register (Account 10 digits, Password 6 to 10 digits)
  const register = (accountId: string, password: string, referralCode?: string, fullName?: string) => {
    if (!/^\d{10}$/.test(accountId.trim())) {
      return { success: false, message: 'El número de cuenta debe tener exactamente 10 dígitos numéricos (ej: 3109876543).' };
    }
    if (!/^\d{6,10}$/.test(password.trim())) {
      return { success: false, message: 'La contraseña debe contener de 6 a 10 dígitos numéricos.' };
    }

    if (users.some((u) => u.accountId === accountId.trim())) {
      return { success: false, message: 'Este número de cuenta ya se encuentra registrado en TOK COIN.' };
    }

    // Check referral
    let verifiedRef: string | undefined = undefined;
    if (referralCode && referralCode.trim() !== '') {
      const trimmed = referralCode.trim().toUpperCase();
      const referrer = users.find((u) => u.referralCode.toUpperCase() === trimmed);
      if (referrer && referrer.accountId !== accountId.trim()) {
        verifiedRef = referrer.referralCode;
      }
    }

    const vip1Data = vipConfig['vip1'] || DEFAULT_VIP_LEVELS['vip1'];
    const now = Date.now();
    const durationMs = vip1Data.durationDays * 24 * 60 * 60 * 1000;

    const newUser: User = {
      id: `usr_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      accountId: accountId.trim(),
      password: password.trim(),
      fullName: fullName?.trim() || `Usuario ${accountId.trim().slice(-4)}`,
      referralCode: generateReferralCode(),
      referredBy: verifiedRef,
      createdAt: now,
      gananciasCop: 0,
      saldoCop: 0,
      totalCommissionsCop: 0,
      totalEarnedCop: 0,
      currentVipId: 'vip1',
      activeVips: {
        vip1: {
          vipId: 'vip1',
          activatedAt: now,
          expiresAt: now + durationMs,
        },
      },
      vipActivatedAt: now,
      vipExpiresAt: now + durationMs,
      virtualDateOffsetDays: 0,
      completedTasks: [],
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentAccountId(newUser.accountId);
    return { success: true, message: '¡Cuenta creada con éxito! Nivel VIP 1 Gratuito activado.' };
  };

  // User Login
  const login = (accountId: string, password: string) => {
    // Check if trying admin credentials on standard login
    if (accountId.trim() === ADMIN_USERNAME && password.trim() === ADMIN_PASSWORD) {
      setIsAdminLoggedIn(true);
      return { success: true, message: 'Acceso de Administrador Maestro concedido.' };
    }

    if (!/^\d{10}$/.test(accountId.trim())) {
      return { success: false, message: 'El número de cuenta debe tener 10 dígitos numéricos (ej: 3109876543).' };
    }
    if (!/^\d{6,10}$/.test(password.trim())) {
      return { success: false, message: 'La contraseña debe tener de 6 a 10 dígitos.' };
    }

    const found = users.find((u) => u.accountId === accountId.trim());
    if (!found) {
      return { success: false, message: 'Cuenta no encontrada. Verifica el número o regístrate.' };
    }
    if (found.password !== password.trim()) {
      return { success: false, message: 'Contraseña incorrecta. Debe ser de 6 a 10 dígitos.' };
    }

    setCurrentAccountId(found.accountId);
    return { success: true, message: '¡Bienvenido a TOK COIN!' };
  };

  const logout = () => {
    setCurrentAccountId(null);
  };

  // Multi-VIP Status check for a specific VIP ID
  const getVipStatusForId = (vipId: string) => {
    const targetVip = vipConfig[vipId] || DEFAULT_VIP_LEVELS[vipId] || DEFAULT_VIP_LEVELS['vip1'];
    if (!currentUser) {
      return {
        level: targetVip,
        isExpired: false,
        daysRemaining: 0,
        vip1CapReached: false,
        dailyTasksDoneToday: 0,
        dailyTasksLimit: targetVip.dailyTasks,
        canDoTasks: false,
        blockReason: 'Inicia sesión para realizar tareas.',
      };
    }

    const activeRecord = currentUser.activeVips?.[vipId] || (currentUser.currentVipId === vipId ? {
      vipId,
      activatedAt: currentUser.vipActivatedAt,
      expiresAt: currentUser.vipExpiresAt,
    } : null);

    if (!activeRecord) {
      return {
        level: targetVip,
        isExpired: false,
        daysRemaining: 0,
        vip1CapReached: false,
        dailyTasksDoneToday: 0,
        dailyTasksLimit: targetVip.dailyTasks,
        canDoTasks: false,
        blockReason: `Nivel ${targetVip.name} no adquirido.`,
      };
    }

    const now = Date.now() + (currentUser.virtualDateOffsetDays || 0) * 86400000;
    const isExpired = activeRecord.expiresAt ? now > activeRecord.expiresAt : false;
    const msRemaining = activeRecord.expiresAt ? Math.max(0, activeRecord.expiresAt - now) : 0;
    const daysRemaining = Math.ceil(msRemaining / (1000 * 60 * 60 * 24));

    // Calculate total earned under VIP 1 to check totalCapLimit ($5.000 COP)
    const vip1Earned = currentUser.completedTasks
      .filter((t) => t.vipId === 'vip1')
      .reduce((acc, t) => acc + t.rewardCop, 0);

    const vip1CapLimit = targetVip.totalCapLimit || 5000;
    const vip1CapReached = targetVip.id === 'vip1' && vip1Earned >= vip1CapLimit;

    // Daily tasks done today FOR THIS SPECIFIC VIP
    const tasksDoneTodayForVip = currentUser.completedTasks.filter(
      (t) => t.dateStr === currentDateStr && t.vipId === vipId
    ).length;
    const dailyTasksLimit = targetVip.dailyTasks;

    let canDoTasks = true;
    let blockReason: string | undefined = undefined;

    if (isExpired) {
      canDoTasks = false;
      blockReason = `Tu membresía ${targetVip.name} ha vencido. Renueva tu VIP para continuar realizando tareas.`;
    } else if (vip1CapReached) {
      canDoTasks = false;
      blockReason = `Límite total alcanzado ($${vip1CapLimit.toLocaleString('es-CO')} COP) en VIP 1 Gratuito. Adquiere VIP 2 para seguir ganando saldo retirable.`;
    } else if (tasksDoneTodayForVip >= dailyTasksLimit) {
      canDoTasks = false;
      blockReason = `Has completado tus ${dailyTasksLimit} tareas de hoy para ${targetVip.name}. Vuelve mañana o realiza tareas de otro VIP activo.`;
    }

    return {
      level: targetVip,
      isExpired,
      daysRemaining,
      vip1CapReached,
      dailyTasksDoneToday: tasksDoneTodayForVip,
      dailyTasksLimit,
      canDoTasks,
      blockReason,
    };
  };

  // Status check for default / primary active VIP
  const getVipStatus = () => {
    const defaultVipId = currentUser?.currentVipId || 'vip1';
    return getVipStatusForId(defaultVipId);
  };

  // Return all currently active VIPs for the user
  const getUserActiveVips = () => {
    if (!currentUser) return [];
    const activeMap = currentUser.activeVips || {
      [currentUser.currentVipId || 'vip1']: {
        vipId: currentUser.currentVipId || 'vip1',
        activatedAt: currentUser.vipActivatedAt,
        expiresAt: currentUser.vipExpiresAt,
      },
    };
    return Object.keys(activeMap).map((id) => getVipStatusForId(id));
  };

  const getTasksCompletedToday = () => {
    if (!currentUser) return [];
    return currentUser.completedTasks.filter((t) => t.dateStr === currentDateStr);
  };

  // Complete a task:
  // Allows specifying for which active VIP the task is being performed
  // VIP 1 -> adds to `gananciasCop` (non-withdrawable, used for VIP purchase)
  // VIP 2 to VIP 5 -> adds to `saldoCop` (WITHDRAWABLE!)
  const completeTask = (task: TaskItem, forVipId?: string) => {
    if (!currentUser) return { success: false, reward: 0, message: 'Debes iniciar sesión.' };

    const targetVipId = forVipId || currentUser.currentVipId || 'vip1';
    const status = getVipStatusForId(targetVipId);
    if (!status.canDoTasks) {
      return { success: false, reward: 0, message: status.blockReason || 'Tareas no disponibles para este nivel VIP.' };
    }

    // Check if task already completed today for this specific VIP
    const alreadyDone = currentUser.completedTasks.some(
      (t) => t.taskId === task.id && t.dateStr === currentDateStr && t.vipId === targetVipId
    );
    if (alreadyDone) {
      return { success: false, reward: 0, message: `Esta tarea ya fue completada hoy para el nivel ${status.level.name}. Selecciona otra.` };
    }

    let reward = status.level.rewardPerTask;

    // If VIP 1, enforce cap limit ($5.000 COP)
    if (status.level.id === 'vip1') {
      const currentVip1Earned = currentUser.completedTasks
        .filter((t) => t.vipId === 'vip1')
        .reduce((sum, t) => sum + t.rewardCop, 0);

      const cap = status.level.totalCapLimit || 5000;
      if (currentVip1Earned + reward > cap) {
        reward = Math.max(0, cap - currentVip1Earned);
      }
    }

    const isVip1 = status.level.id === 'vip1';

    const newRecord: CompletedTaskRecord = {
      id: `cmp_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      taskId: task.id,
      taskTitle: task.title,
      vipId: status.level.id,
      rewardCop: reward,
      dateStr: currentDateStr,
      timestamp: Date.now(),
    };

    const newTx: Transaction = {
      id: `tx_${Date.now()}_task`,
      userId: currentUser.id,
      userAccountId: currentUser.accountId,
      userFullName: currentUser.fullName,
      type: isVip1 ? 'tarea_vip1' : 'tarea_vip',
      amount: reward,
      description: `Recompensa por tarea: ${task.title} (${status.level.name})`,
      dateStr: currentDateStr,
      timestamp: Date.now(),
      status: 'completado',
      method: isVip1 ? 'Ganancias (VIP 1)' : 'Saldo (Retirable)',
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== currentUser.id) return u;
        return {
          ...u,
          gananciasCop: isVip1 ? u.gananciasCop + reward : u.gananciasCop,
          saldoCop: !isVip1 ? u.saldoCop + reward : u.saldoCop,
          totalEarnedCop: u.totalEarnedCop + reward,
          completedTasks: [newRecord, ...u.completedTasks],
        };
      })
    );

    setTransactions((prev) => [newTx, ...prev]);

    return {
      success: true,
      reward,
      message: isVip1
        ? `¡Tarea verificada! Recibiste $${reward.toLocaleString('es-CO')} COP en "Ganancias" (para compras VIP).`
        : `¡Tarea verificada! Recibiste $${reward.toLocaleString('es-CO')} COP en tu "Saldo Retirable".`,
    };
  };

  // Purchase / Add VIP:
  // Multi-VIP allowed: "si el usuario recarga otra vez su cuenta y quiere comprar otro VIP también lo puede hacer libremente no porque tienen VIP 2 no puede comprar el tres o el cuatro... se puede trabajar con VIP dos y VIP 3 al mismo tiempo y así con los demás"
  // Uses `gananciasCop` first, then `saldoCop` if needed.
  const purchaseVip = (vipId: string) => {
    if (!currentUser) return { success: false, message: 'Inicia sesión primero.' };

    const targetVip = vipConfig[vipId];
    if (!targetVip) return { success: false, message: 'Nivel VIP no válido.' };

    const cost = targetVip.cost;
    const totalAvailable = currentUser.gananciasCop + currentUser.saldoCop;

    if (totalAvailable < cost) {
      return {
        success: false,
        message: `Saldo insuficiente ($${totalAvailable.toLocaleString(
          'es-CO'
        )} COP total disponible). El costo es de $${cost.toLocaleString('es-CO')} COP. Puedes recargar mediante QR de pago.`,
      };
    }

    // Deduct from gananciasCop first, then saldoCop
    let deductGanancias = Math.min(currentUser.gananciasCop, cost);
    let deductSaldo = cost - deductGanancias;

    const now = Date.now();
    const durationMs = targetVip.durationDays * 24 * 60 * 60 * 1000;

    const txBuy: Transaction = {
      id: `tx_${Date.now()}_vip`,
      userId: currentUser.id,
      userAccountId: currentUser.accountId,
      userFullName: currentUser.fullName,
      type: 'compra_vip',
      amount: -cost,
      description: `Adquisición de membresía ${targetVip.name} (${targetVip.durationDays} días)`,
      dateStr: currentDateStr,
      timestamp: now,
      status: 'completado',
      method: deductSaldo > 0 ? 'Ganancias + Saldo' : 'Ganancias QR',
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== currentUser.id) return u;
        const prevActive = u.activeVips || {
          [u.currentVipId || 'vip1']: {
            vipId: u.currentVipId || 'vip1',
            activatedAt: u.vipActivatedAt,
            expiresAt: u.vipExpiresAt,
          },
        };

        return {
          ...u,
          gananciasCop: u.gananciasCop - deductGanancias,
          saldoCop: u.saldoCop - deductSaldo,
          currentVipId: vipId,
          activeVips: {
            ...prevActive,
            [vipId]: {
              vipId,
              activatedAt: now,
              expiresAt: now + durationMs,
            },
          },
          vipActivatedAt: now,
          vipExpiresAt: now + durationMs,
        };
      })
    );

    setTransactions((prev) => [txBuy, ...prev]);

    return {
      success: true,
      message: `¡Membresía ${targetVip.name} activada con éxito! Tienes ${targetVip.dailyTasks} tareas diarias asignadas. Puedes trabajar con todos tus niveles VIP al mismo tiempo.`,
    };
  };

  // Request a Recharge with QR & Gallery Voucher Upload:
  // "pantalla con instrucciones, QR configurable, importe y carga de comprobante desde la galería.
  // Las solicitudes deben llegar al administrador. No acreditar saldo ni activar VIP hasta verificar y aprobar el pago."
  const requestRecharge = (amount: number, method: string, receiptImageUrl: string) => {
    if (!currentUser) return { success: false, message: 'Inicia sesión.' };
    if (amount < 10000) return { success: false, message: 'El importe mínimo de recarga es de $10.000 COP.' };
    if (!receiptImageUrl || receiptImageUrl.trim() === '') {
      return { success: false, message: 'Debes adjuntar la imagen del comprobante de pago desde tu galería.' };
    }

    const refCode = `QR-${method.slice(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;

    const newTx: Transaction = {
      id: `tx_rec_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: currentUser.id,
      userAccountId: currentUser.accountId,
      userFullName: currentUser.fullName,
      type: 'recarga_qr',
      amount: amount,
      description: `Solicitud de recarga por ${method} - En espera de aprobación`,
      dateStr: currentDateStr,
      timestamp: Date.now(),
      status: 'pendiente',
      method,
      receiptImageUrl,
      reference: refCode,
    };

    setTransactions((prev) => [newTx, ...prev]);

    return {
      success: true,
      message: `Comprobante enviado con éxito (Ref: ${refCode}). Tu solicitud está en verificación por el administrador. El saldo se acreditará una vez aprobado.`,
    };
  };

  // Request Withdrawal (Retiros):
  // "mínimo $10.000 COP; comisión del 15 %; solicitudes de jueves a domingo, de 1:00 p. m. a 5:00 p. m., hora de Colombia;
  // procesamiento de hasta 24 horas. Formulario con nombre completo, cuenta bancaria, importe y contraseña de acceso.
  // Antes de confirmar, mostrar comisión, importe neto y saldo restante. Reservar el saldo mientras la solicitud esté pendiente y devolverlo si se rechaza."
  const requestWithdrawal = (
    amount: number,
    destinationAccount: string,
    fullName: string,
    passwordAttempt: string,
    bankMethod: string
  ) => {
    if (!currentUser) return { success: false, message: 'Inicia sesión.' };

    // Verify Password
    if (currentUser.password !== passwordAttempt.trim()) {
      return { success: false, message: 'Contraseña de acceso incorrecta. Verifica tu PIN.' };
    }

    // Verify Min Amount
    if (amount < 10000) {
      return { success: false, message: 'El importe mínimo de retiro es de $10.000 COP.' };
    }

    // Verify Schedule (Thursday to Sunday, 13:00 to 17:00 COL)
    const scheduleCheck = checkWithdrawalSchedule(companySettings.allowWithdrawalsAnytimeForTesting);
    if (!scheduleCheck.allowed) {
      return { success: false, message: scheduleCheck.message };
    }

    // Verify withdrawable balance (Saldo)
    if (amount > currentUser.saldoCop) {
      return {
        success: false,
        message: `Saldo retirable insuficiente. Tu "Saldo" disponible para retiros es de $${currentUser.saldoCop.toLocaleString(
          'es-CO'
        )} COP. (Recuerda que el saldo en "Ganancias" es exclusivo para compras VIP).`,
      };
    }

    if (!destinationAccount || destinationAccount.trim().length < 6) {
      return { success: false, message: 'Ingresa un número de cuenta o celular bancario válido.' };
    }

    if (!fullName || fullName.trim().length < 3) {
      return { success: false, message: 'Ingresa el nombre completo del titular de la cuenta bancaria.' };
    }

    // Calculate 15% commission fee and net payout
    const fee = Math.round(amount * 0.15);
    const netAmount = amount - fee;

    const ref = `WTH-${Math.floor(100000 + Math.random() * 900000)}`;

    const newTx: Transaction = {
      id: `tx_wth_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: currentUser.id,
      userAccountId: currentUser.accountId,
      userFullName: fullName.trim(),
      type: 'retiro',
      amount: -amount,
      fee: fee,
      netAmount: netAmount,
      description: `Solicitud de retiro a ${bankMethod} (${destinationAccount})`,
      dateStr: currentDateStr,
      timestamp: Date.now(),
      status: 'pendiente',
      method: bankMethod,
      destinationAccount: destinationAccount.trim(),
      reference: ref,
    };

    // Reserve saldo immediately while pending!
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== currentUser.id) return u;
        return {
          ...u,
          saldoCop: u.saldoCop - amount,
        };
      })
    );

    setTransactions((prev) => [newTx, ...prev]);

    return {
      success: true,
      fee,
      netAmount,
      message: `Solicitud de retiro generada con éxito (Ref: ${ref}). Comisión del 15% ($${fee.toLocaleString(
        'es-CO'
      )} COP). Importe neto a transferir: $${netAmount.toLocaleString('es-CO')} COP en hasta 24 horas.`,
    };
  };

  // ADMIN OPERATIONS
  // 1. Approve Recharge:
  // "comisión automática del 10 % para quien invitó, calculada sobre cada recarga aprobada del usuario invitado.
  // Ejemplo: recarga de $40.000 = comisión de $4.000. Registrar la relación de invitación permanentemente y evitar autorreferencias y comisiones duplicadas."
  const adminApproveRecharge = (transactionId: string) => {
    const tx = transactions.find((t) => t.id === transactionId);
    if (!tx || tx.type !== 'recarga_qr' || tx.status !== 'pendiente') {
      return { success: false, message: 'Transacción no encontrada o ya procesada.' };
    }

    const targetUser = users.find((u) => u.id === tx.userId || u.accountId === tx.userAccountId);
    if (!targetUser) {
      return { success: false, message: 'Usuario de la recarga no encontrado en la base de datos.' };
    }

    const rechargeAmount = tx.amount;

    // Credit user's Ganancias (dedicated for VIP buying)
    let updatedUsers = users.map((u) => {
      if (u.id === targetUser.id) {
        return {
          ...u,
          gananciasCop: u.gananciasCop + rechargeAmount,
          totalEarnedCop: u.totalEarnedCop + rechargeAmount,
        };
      }
      return u;
    });

    // Check for referrer for 10% commission
    let newTransactions: Transaction[] = [];

    if (targetUser.referredBy && !tx.referralCommissionProcessed) {
      const referrer = users.find(
        (u) => u.referralCode === targetUser.referredBy && u.accountId !== targetUser.accountId
      );
      if (referrer) {
        const commissionAmount = Math.round(rechargeAmount * 0.1); // 10%
        // Credit referrer's withdrawable "saldoCop"!
        updatedUsers = updatedUsers.map((u) => {
          if (u.id === referrer.id) {
            return {
              ...u,
              saldoCop: u.saldoCop + commissionAmount,
              totalCommissionsCop: (u.totalCommissionsCop || 0) + commissionAmount,
              totalEarnedCop: u.totalEarnedCop + commissionAmount,
            };
          }
          return u;
        });

        const commissionTx: Transaction = {
          id: `tx_com_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          userId: referrer.id,
          userAccountId: referrer.accountId,
          userFullName: referrer.fullName,
          type: 'comision_referido',
          amount: commissionAmount,
          description: `Comisión 10% por recarga aprobada de tu invitado ${targetUser.accountId} ($${rechargeAmount.toLocaleString(
            'es-CO'
          )} COP)`,
          dateStr: currentDateStr,
          timestamp: Date.now(),
          status: 'completado',
          method: 'Comisión Red',
          reference: `COM-10-${tx.reference || tx.id}`,
        };

        newTransactions.push(commissionTx);
      }
    }

    setUsers(updatedUsers);

    // Update original transaction to completed
    setTransactions((prev) => {
      const updated = prev.map((t) => {
        if (t.id === transactionId) {
          return {
            ...t,
            status: 'completado' as const,
            referralCommissionProcessed: true,
            description: `Recarga de $${rechargeAmount.toLocaleString(
              'es-CO'
            )} COP aprobada y acreditada en Ganancias`,
          };
        }
        return t;
      });
      return [...newTransactions, ...updated];
    });

    return {
      success: true,
      message: `Recarga aprobada. Se acreditaron $${rechargeAmount.toLocaleString(
        'es-CO'
      )} COP a la cuenta ${targetUser.accountId} y se liquidó la comisión correspondiente.`,
    };
  };

  // 2. Reject Recharge:
  const adminRejectRecharge = (transactionId: string, notes = 'Comprobante no válido o pago no recibido') => {
    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === transactionId) {
          return {
            ...t,
            status: 'rechazado' as const,
            adminNotes: notes,
            description: `Recarga rechazada: ${notes}`,
          };
        }
        return t;
      })
    );
    return { success: true, message: 'Recarga rechazada correctamente.' };
  };

  // 3. Approve Withdrawal:
  const adminApproveWithdrawal = (transactionId: string) => {
    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === transactionId) {
          return {
            ...t,
            status: 'completado' as const,
            description: `Retiro procesado y transferido exitosamente a ${t.method} (${t.destinationAccount})`,
          };
        }
        return t;
      })
    );
    return { success: true, message: 'Retiro marcado como completado y pagado.' };
  };

  // 4. Reject Withdrawal (Refunds reserved balance):
  // "Reservar el saldo mientras la solicitud esté pendiente y devolverlo si se rechaza."
  const adminRejectWithdrawal = (transactionId: string, notes = 'Datos bancarios erróneos o inconsistentes') => {
    const tx = transactions.find((t) => t.id === transactionId);
    if (!tx || tx.type !== 'retiro' || tx.status !== 'pendiente') {
      return { success: false, message: 'Retiro no encontrado o ya procesado.' };
    }

    const refundAmount = Math.abs(tx.amount);

    // Return funds to user's saldoCop
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === tx.userId || u.accountId === tx.userAccountId) {
          return {
            ...u,
            saldoCop: u.saldoCop + refundAmount,
          };
        }
        return u;
      })
    );

    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === transactionId) {
          return {
            ...t,
            status: 'rechazado' as const,
            adminNotes: notes,
            description: `Retiro rechazado: ${notes} (Saldo de $${refundAmount.toLocaleString(
              'es-CO'
            )} devuelto a la cuenta)`,
          };
        }
        return t;
      })
    );

    return {
      success: true,
      message: `Retiro rechazado. Se devolvieron $${refundAmount.toLocaleString(
        'es-CO'
      )} COP al saldo retirable del usuario.`,
    };
  };

  // 5. Bulk Credit to All Users:
  // "Quiero un botón para cargar saldo a todas las cuentas automáticamente... ese botón se utiliza para cargar comisiones al botón saldo que también se puede retirar"
  const adminBulkCreditAllUsers = (amount: number, concept: string) => {
    if (amount <= 0) return { success: false, message: 'El importe debe ser mayor a 0.', affectedCount: 0 };

    const now = Date.now();
    const newTxList: Transaction[] = [];

    setUsers((prev) =>
      prev.map((u) => {
        const tx: Transaction = {
          id: `tx_bulk_${Date.now()}_${u.accountId}`,
          userId: u.id,
          userAccountId: u.accountId,
          userFullName: u.fullName,
          type: 'abono_admin',
          amount: amount,
          description: `Abono masivo administrativo: ${concept}`,
          dateStr: currentDateStr,
          timestamp: now,
          status: 'completado',
          method: 'Admin Saldo Masivo',
        };
        newTxList.push(tx);

        return {
          ...u,
          saldoCop: u.saldoCop + amount,
          totalEarnedCop: u.totalEarnedCop + amount,
        };
      })
    );

    setTransactions((prev) => [...newTxList, ...prev]);

    return {
      success: true,
      message: `Se han acreditado exitosamente $${amount.toLocaleString(
        'es-CO'
      )} COP en el "Saldo Retirable" de ${users.length} cuentas registradas.`,
      affectedCount: users.length,
    };
  };

  // 6. Adjust individual user balances:
  const adminAdjustUserBalance = (
    accountId: string,
    saldoDelta: number,
    gananciasDelta: number,
    reason: string
  ) => {
    const target = users.find((u) => u.accountId === accountId);
    if (!target) return { success: false, message: 'Usuario no encontrado.' };

    const newSaldo = Math.max(0, target.saldoCop + saldoDelta);
    const newGanancias = Math.max(0, target.gananciasCop + gananciasDelta);

    const tx: Transaction = {
      id: `tx_adj_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: target.id,
      userAccountId: target.accountId,
      userFullName: target.fullName,
      type: 'abono_admin',
      amount: saldoDelta + gananciasDelta,
      description: `Ajuste administrativo manual: ${reason} (Saldo: ${saldoDelta >= 0 ? '+' : ''}${saldoDelta}, Ganancias: ${gananciasDelta >= 0 ? '+' : ''}${gananciasDelta})`,
      dateStr: currentDateStr,
      timestamp: Date.now(),
      status: 'completado',
      method: 'Admin Manual',
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.accountId === accountId) {
          return {
            ...u,
            saldoCop: newSaldo,
            gananciasCop: newGanancias,
          };
        }
        return u;
      })
    );

    setTransactions((prev) => [tx, ...prev]);

    return {
      success: true,
      message: `Balances actualizados para la cuenta ${accountId}. Saldo: $${newSaldo.toLocaleString('es-CO')}, Ganancias: $${newGanancias.toLocaleString('es-CO')}.`,
    };
  };

  // Add balance to individual user (Saldo or Ganancias)
  const adminAddUserBalance = (
    accountId: string,
    balanceType: 'saldo' | 'ganancias',
    amount: number,
    reason: string
  ) => {
    const target = users.find((u) => u.accountId === accountId);
    if (!target) return { success: false, message: 'Usuario no encontrado.' };
    if (amount <= 0) return { success: false, message: 'El importe a agregar debe ser mayor a 0.' };

    const isSaldo = balanceType === 'saldo';
    const tx: Transaction = {
      id: `tx_add_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: target.id,
      userAccountId: target.accountId,
      userFullName: target.fullName,
      type: 'abono_admin',
      amount: amount,
      description: `Abono de saldo administrativo: ${reason} (Acreditado en ${isSaldo ? 'Saldo Retirable' : 'Ganancias VIP'})`,
      dateStr: currentDateStr,
      timestamp: Date.now(),
      status: 'completado',
      method: 'Admin Manual',
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.accountId === accountId) {
          return {
            ...u,
            saldoCop: isSaldo ? u.saldoCop + amount : u.saldoCop,
            gananciasCop: !isSaldo ? u.gananciasCop + amount : u.gananciasCop,
            totalEarnedCop: u.totalEarnedCop + amount,
          };
        }
        return u;
      })
    );

    setTransactions((prev) => [tx, ...prev]);

    return {
      success: true,
      message: `Se agregaron exitosamente $${amount.toLocaleString('es-CO')} COP en ${
        isSaldo ? 'Saldo Retirable' : 'Ganancias VIP'
      } a la cuenta ${accountId}.`,
    };
  };

  // Remove / Deduct balance from individual user
  const adminRemoveUserBalance = (
    accountId: string,
    balanceType: 'saldo' | 'ganancias',
    amount: number,
    reason: string
  ) => {
    const target = users.find((u) => u.accountId === accountId);
    if (!target) return { success: false, message: 'Usuario no encontrado.' };
    if (amount <= 0) return { success: false, message: 'El importe a deducir debe ser mayor a 0.' };

    const isSaldo = balanceType === 'saldo';
    const currentVal = isSaldo ? target.saldoCop : target.gananciasCop;
    const finalVal = Math.max(0, currentVal - amount);
    const actualDeducted = currentVal - finalVal;

    const tx: Transaction = {
      id: `tx_sub_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: target.id,
      userAccountId: target.accountId,
      userFullName: target.fullName,
      type: 'abono_admin',
      amount: -actualDeducted,
      description: `Deducción de saldo administrativo: ${reason} (Retirado de ${isSaldo ? 'Saldo' : 'Ganancias'})`,
      dateStr: currentDateStr,
      timestamp: Date.now(),
      status: 'completado',
      method: 'Admin Manual',
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.accountId === accountId) {
          return {
            ...u,
            saldoCop: isSaldo ? finalVal : u.saldoCop,
            gananciasCop: !isSaldo ? finalVal : u.gananciasCop,
          };
        }
        return u;
      })
    );

    setTransactions((prev) => [tx, ...prev]);

    return {
      success: true,
      message: `Se dedujeron $${actualDeducted.toLocaleString('es-CO')} COP de la cuenta ${accountId}.`,
    };
  };

  // Manually activate VIP for user
  const adminManualActivateVip = (accountId: string, vipId: string) => {
    const target = users.find((u) => u.accountId === accountId);
    if (!target) return { success: false, message: 'Usuario no encontrado.' };
    const targetVip = vipConfig[vipId] || DEFAULT_VIP_LEVELS[vipId];
    if (!targetVip) return { success: false, message: 'Nivel VIP inválido.' };

    const now = Date.now();
    const durationMs = targetVip.durationDays * 24 * 60 * 60 * 1000;

    const tx: Transaction = {
      id: `tx_admin_vip_${Date.now()}`,
      userId: target.id,
      userAccountId: target.accountId,
      userFullName: target.fullName,
      type: 'compra_vip',
      amount: 0,
      description: `Activación manual administrativa de membresía ${targetVip.name}`,
      dateStr: currentDateStr,
      timestamp: now,
      status: 'completado',
      method: 'Admin Directo',
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.accountId === accountId) {
          const prevActive = u.activeVips || {
            [u.currentVipId || 'vip1']: {
              vipId: u.currentVipId || 'vip1',
              activatedAt: u.vipActivatedAt,
              expiresAt: u.vipExpiresAt,
            },
          };
          return {
            ...u,
            currentVipId: vipId,
            activeVips: {
              ...prevActive,
              [vipId]: {
                vipId,
                activatedAt: now,
                expiresAt: now + durationMs,
              },
            },
            vipActivatedAt: now,
            vipExpiresAt: now + durationMs,
          };
        }
        return u;
      })
    );

    setTransactions((prev) => [tx, ...prev]);

    return {
      success: true,
      message: `Nivel ${targetVip.name} activado manualmente en la cuenta ${accountId} por ${targetVip.durationDays} días.`,
    };
  };

  // 7. Delete User:
  // Immediate permanent deletion with synchronous storage sync
  const adminDeleteUser = (accountId: string) => {
    const clean = accountId.trim();
    if (clean === currentAccountId) {
      setCurrentAccountId(null);
      try {
        localStorage.removeItem(SESSION_STORAGE_KEY);
      } catch (e) {
        console.error('Session remove error', e);
      }
    }

    const updatedUsers = users.filter((u) => u.accountId !== clean && u.id !== clean);
    const updatedTransactions = transactions.filter((t) => t.userAccountId !== clean && t.userId !== clean);

    setUsers(updatedUsers);
    setTransactions(updatedTransactions);

    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updatedUsers));
      localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(updatedTransactions));
    } catch (e) {
      console.error('Error syncing deletion to localStorage', e);
    }

    return { success: true, message: `Cuenta ${clean} eliminada permanentemente del sistema.` };
  };

  // Settings & Configuration Updates
  const updateCompanySettings = (settings: CompanySettings) => {
    setCompanySettings(settings);
    saveCompanySettings(settings);
  };

  const updateVipConfig = (newConfig: Record<string, VipLevel>) => {
    setVipConfig(newConfig);
    saveVipConfig(newConfig);
  };

  const resetAllVipConfig = () => {
    const def = resetVipConfig();
    setVipConfig(def);
  };

  const advanceSimulatedDay = (days = 1) => {
    if (!currentUser) return;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== currentUser.id) return u;
        return {
          ...u,
          virtualDateOffsetDays: (u.virtualDateOffsetDays || 0) + days,
        };
      })
    );
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        vipConfig,
        companySettings,
        currentDateStr,
        isAdminLoggedIn,
        adminLogin,
        adminLogout,
        login,
        register,
        logout,
        completeTask,
        purchaseVip,
        requestRecharge,
        requestWithdrawal,
        adminApproveRecharge,
        adminRejectRecharge,
        adminApproveWithdrawal,
        adminRejectWithdrawal,
        adminBulkCreditAllUsers,
        adminAdjustUserBalance,
        adminAddUserBalance,
        adminRemoveUserBalance,
        adminManualActivateVip,
        adminDeleteUser,
        updateCompanySettings,
        updateVipConfig,
        resetAllVipConfig,
        advanceSimulatedDay,
        getTasksCompletedToday,
        getVipStatus,
        getVipStatusForId,
        getUserActiveVips,
        allUsersList: users,
        allTransactions: transactions,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
