import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { AuthView } from './views/AuthView';
import { HomeView } from './views/HomeView';
import { TasksView } from './views/TasksView';
import { VipView } from './views/VipView';
import { WalletView } from './views/WalletView';
import { ReferralView } from './views/ReferralView';
import { RechargeModal } from './components/RechargeModal';
import { WithdrawModal } from './components/WithdrawModal';
import { AdminPanel } from './components/AdminPanel';

function AppContent() {
  const { currentUser, isAdminLoggedIn } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [isRechargeOpen, setIsRechargeOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  // If user is not logged in, show Auth View (which has the semi-hidden admin login button)
  if (!currentUser) {
    return (
      <>
        <AuthView onOpenAdminDirectly={() => setIsAdminPanelOpen(true)} />
        {isAdminLoggedIn && (
          <AdminPanel
            isOpen={isAdminPanelOpen}
            onClose={() => setIsAdminPanelOpen(false)}
          />
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#060608] text-zinc-100 flex flex-col selection:bg-rose-600 selection:text-white">
      {/* Top Navbar & Mobile Bottom Bar */}
      <Navbar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onOpenRecharge={() => setIsRechargeOpen(true)}
        onOpenWithdraw={() => setIsWithdrawOpen(true)}
        onOpenAdmin={() => setIsAdminPanelOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 pt-5">
        {currentTab === 'home' && (
          <HomeView
            onTabChange={setCurrentTab}
            onOpenRecharge={() => setIsRechargeOpen(true)}
            onOpenWithdraw={() => setIsWithdrawOpen(true)}
          />
        )}
        {currentTab === 'tasks' && <TasksView onTabChange={setCurrentTab} />}
        {currentTab === 'vip' && (
          <VipView
            onOpenRecharge={() => setIsRechargeOpen(true)}
          />
        )}
        {currentTab === 'wallet' && (
          <WalletView
            onOpenRecharge={() => setIsRechargeOpen(true)}
            onOpenWithdraw={() => setIsWithdrawOpen(true)}
          />
        )}
        {currentTab === 'referral' && <ReferralView />}
      </main>

      {/* Modals */}
      <RechargeModal isOpen={isRechargeOpen} onClose={() => setIsRechargeOpen(false)} />
      <WithdrawModal isOpen={isWithdrawOpen} onClose={() => setIsWithdrawOpen(false)} />
      <AdminPanel isOpen={isAdminPanelOpen} onClose={() => setIsAdminPanelOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
