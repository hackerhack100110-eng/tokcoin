/**
 * Core domain types for TOK COIN
 */

export interface VipLevel {
  id: string; // 'vip1' | 'vip2' | 'vip3' | 'vip4' | 'vip5'
  level: number;
  name: string;
  cost: number; // in COP
  dailyTasks: number; // e.g. 5, 5, 7, 7, 9
  dailyReward: number; // in COP
  rewardPerTask: number; // COP earned per task
  durationDays: number; // 2, 60, 90, 90, 90
  totalEstimated: number; // in COP (78000, 180000, 225000, 405000)
  totalCapLimit?: number; // VIP 1 has 5000 COP max limit
  badgeColor: string;
  isFree?: boolean;
  tagline: string;
}

export interface TaskItem {
  id: string;
  title: string;
  category: 'video' | 'like' | 'follow' | 'share';
  platform: 'TikTok' | 'YouTube Shorts' | 'Instagram Reels' | 'YouTube';
  creator: string;
  durationSeconds: number;
  videoUrl: string;
  youtubeId?: string; // Optional YouTube ID or Shorts embed ID
  thumbnail: string;
  description: string;
}

export interface CompletedTaskRecord {
  id: string;
  taskId: string;
  taskTitle: string;
  vipId: string;
  rewardCop: number;
  dateStr: string; // YYYY-MM-DD
  timestamp: number;
}

export interface Transaction {
  id: string;
  userId: string;
  userAccountId: string;
  userFullName?: string;
  type: 'tarea_vip1' | 'tarea_vip' | 'recarga_qr' | 'retiro' | 'compra_vip' | 'comision_referido' | 'abono_admin';
  amount: number; // gross amount
  fee?: number; // fee deducted (e.g. 15% on withdrawals)
  netAmount?: number; // net amount credited/paid out
  description: string;
  dateStr: string;
  timestamp: number;
  status: 'pendiente' | 'completado' | 'rechazado';
  method?: string; // Nequi, Daviplata, Bancolombia, PSE, USDT, Saldo, Ganancias
  destinationAccount?: string; // bank account or phone for withdrawal
  receiptImageUrl?: string; // Base64 or image URL from gallery for recharges
  reference?: string;
  adminNotes?: string;
  referralCommissionProcessed?: boolean;
}

export interface ActiveVipRecord {
  vipId: string;
  activatedAt: number;
  expiresAt: number;
}

export interface User {
  id: string;
  accountId: string; // 10 digits
  password: string; // 6 to 10 digits
  fullName?: string;
  referralCode: string; // unique code e.g. TOK-829471
  referredBy?: string; // referralCode of person who invited
  createdAt: number;
  // Two distinct balances as requested:
  // 1. Ganancias: VIP 1 earnings + QR recharges (used ONLY to buy VIP, NOT withdrawable)
  gananciasCop: number;
  // 2. Saldo: Earnings from VIP 2 to VIP 5 + 10% referral commissions + admin bulk credits (WITHDRAWABLE)
  saldoCop: number;
  // Total commissions earned through referrals
  totalCommissionsCop: number;
  totalEarnedCop: number;
  currentVipId: string;
  activeVips?: Record<string, ActiveVipRecord>; // Multi-VIP support: can work VIP 2, VIP 3 simultaneously
  vipActivatedAt: number;
  vipExpiresAt: number; // timestamp
  completedTasks: CompletedTaskRecord[];
  virtualDateOffsetDays: number;
}

export interface CompanySettings {
  whatsappGroupUrl: string;
  companyQrImageUrl: string;
  nequiNumber: string;
  daviplataNumber: string;
  bancolombiaAccount: string;
  allowWithdrawalsAnytimeForTesting: boolean; // bypass day/hour check for test mode
}
