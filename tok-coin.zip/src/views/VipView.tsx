import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { formatCOP, OFFICIAL_TOK_LOGO } from '../config/vipConfig';
import {
  Crown,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Zap,
  ArrowRight,
  Coins,
  ArrowDownLeft,
  RefreshCw,
} from 'lucide-react';

interface VipViewProps {
  onOpenRecharge: () => void;
}

export const VipView: React.FC<VipViewProps> = ({ onOpenRecharge }) => {
  const { currentUser, vipConfig, getVipStatus, getVipStatusForId, getUserActiveVips, purchaseVip } = useAuth();
  const vipStatus = getVipStatus();
  const activeVipsList = getUserActiveVips();

  const [purchasingVipId, setPurchasingVipId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!currentUser) return null;

  const totalFundsAvailable = currentUser.gananciasCop + currentUser.saldoCop;

  const handlePurchase = (vipId: string) => {
    setActionMessage(null);
    const res = purchaseVip(vipId);
    if (res.success) {
      setActionMessage({ type: 'success', text: res.message });
      setPurchasingVipId(null);
      setTimeout(() => setActionMessage(null), 4000);
    } else {
      setActionMessage({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Hero Header */}
      <div className="p-6 sm:p-8 rounded-3xl tok-gradient-card border border-zinc-800 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/60 border border-rose-500/30 text-xs text-rose-300 font-bold">
              <Crown className="w-3.5 h-3.5 text-rose-500" /> SISTEMA MULTI-VIP SIMULTÁNEO
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Membresías VIP TOK COIN
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
              Puedes adquirir y activar múltiples niveles VIP a la vez (ejemplo: trabajar con VIP 2 y VIP 3 en simultáneo). Cada nivel tiene sus tareas diarias independientes y ganancias 100% retirables (VIP 2 a VIP 5).
            </p>
          </div>

          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl overflow-hidden border-2 border-red-500/50 bg-black shadow-xl shrink-0 self-start md:self-center">
            <img src={OFFICIAL_TOK_LOGO} alt="TOK COIN Logo" className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Current Active VIPs & Balances */}
        <div className="mt-5 p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="p-2.5 rounded-xl bg-zinc-800 border border-zinc-700 text-rose-400 font-bold text-xs">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] text-zinc-400">Tus Niveles VIP Activos:</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {activeVipsList.map((av) => (
                  <span
                    key={av.level.id}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold border flex items-center gap-1.5 ${av.level.badgeColor}`}
                  >
                    <span>{av.level.name}</span>
                    <span className="text-[10px] text-emerald-400">
                      ({av.daysRemaining}d restantes)
                    </span>
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <div>
              <span className="text-zinc-400 text-[11px] block">Ganancias (Para VIP):</span>
              <span className="font-mono font-bold text-white text-sm">
                {formatCOP(currentUser.gananciasCop)}
              </span>
            </div>
            <div>
              <span className="text-zinc-400 text-[11px] block">Saldo Retirable:</span>
              <span className="font-mono font-bold text-emerald-400 text-sm">
                {formatCOP(currentUser.saldoCop)}
              </span>
            </div>
            <button
              onClick={onOpenRecharge}
              className="py-2 px-3 rounded-xl tok-gradient-red text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5"
            >
              <ArrowDownLeft className="w-3.5 h-3.5" /> Recargar Saldo QR
            </button>
          </div>
        </div>
      </div>

      {/* Action feedback */}
      {actionMessage && (
        <div
          className={`p-4 rounded-2xl border text-xs sm:text-sm font-semibold flex items-center gap-3 animate-fadeIn ${
            actionMessage.type === 'success'
              ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-300'
              : 'bg-rose-950/50 border-rose-500/50 text-rose-300'
          }`}
        >
          {actionMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          )}
          <span>{actionMessage.text}</span>
        </div>
      )}

      {/* VIP Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.values(vipConfig).map((lvl) => {
          const status = getVipStatusForId(lvl.id);
          const isThisActive = !status.isExpired && Boolean(currentUser.activeVips?.[lvl.id] || currentUser.currentVipId === lvl.id);
          const isBuyingThis = purchasingVipId === lvl.id;
          const canAfford = totalFundsAvailable >= lvl.cost;

          return (
            <div
              key={lvl.id}
              className={`rounded-3xl p-6 flex flex-col justify-between transition-all relative overflow-hidden ${
                isThisActive
                  ? 'bg-gradient-to-b from-zinc-900 via-zinc-950 to-zinc-950 border-2 border-emerald-500/70 shadow-2xl shadow-emerald-950/30'
                  : 'tok-gradient-card border border-zinc-800 hover:border-zinc-700 shadow-xl'
              }`}
            >
              {/* Top Level Header */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-xl text-white">{lvl.name}</span>
                    {lvl.isFree && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                        GRATIS
                      </span>
                    )}
                  </div>
                  {isThisActive && (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-600/90 text-[10px] font-bold uppercase tracking-wider text-white shadow-sm flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Activo ({status.daysRemaining}d)
                    </span>
                  )}
                </div>

                {/* Price Display */}
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-3xl font-black text-white font-mono tracking-tight">
                      {lvl.isFree ? 'Gratis' : formatCOP(lvl.cost)}
                    </span>
                    {!lvl.isFree && <span className="text-xs text-zinc-500 font-semibold">COP</span>}
                  </div>
                  <p className="text-xs text-zinc-400 mt-1">{lvl.tagline}</p>
                </div>

                {/* Feature breakdown */}
                <div className="space-y-2.5 pt-4 border-t border-zinc-800/80 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-rose-500" /> Tareas Diarias:
                    </span>
                    <strong className="text-white font-mono font-bold">{lvl.dailyTasks} tareas / día</strong>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> Ganancia Diaria:
                    </span>
                    <strong className="text-emerald-400 font-mono font-bold">
                      {formatCOP(lvl.dailyReward)} COP
                    </strong>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-zinc-400" /> Por Tarea:
                    </span>
                    <span className="text-zinc-300 font-mono">
                      ~{formatCOP(lvl.rewardPerTask)} COP
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-rose-400" /> Periodo Activo:
                    </span>
                    <strong className="text-white font-mono font-bold">{lvl.durationDays} días</strong>
                  </div>

                  {lvl.totalCapLimit && (
                    <div className="flex items-center justify-between text-amber-300/90 bg-amber-950/20 p-2 rounded-lg border border-amber-500/20">
                      <span>Límite acumulado (bloqueo):</span>
                      <strong className="font-mono">{formatCOP(lvl.totalCapLimit)} COP</strong>
                    </div>
                  )}

                  <div className="pt-2 border-t border-zinc-800/60 flex items-center justify-between">
                    <span className="text-zinc-400 font-medium">Total Estimado*:</span>
                    <strong className="text-base font-black text-white font-mono">
                      {formatCOP(lvl.totalEstimated)} COP
                    </strong>
                  </div>
                </div>
              </div>

              {/* Action purchase button */}
              <div className="mt-6 pt-4 border-t border-zinc-800/80">
                {isBuyingThis ? (
                  <div className="space-y-3 bg-zinc-900/90 p-3.5 rounded-2xl border border-zinc-700 animate-fadeIn text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">Confirmar Adquisición:</span>
                      <button
                        onClick={() => setPurchasingVipId(null)}
                        className="text-zinc-400 hover:text-white text-[11px]"
                      >
                        Cancelar
                      </button>
                    </div>

                    <div className="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
                      <div className="flex justify-between">
                        <span>Costo membresía:</span>
                        <strong className="font-mono text-white">{formatCOP(lvl.cost)} COP</strong>
                      </div>
                      <div className="flex justify-between text-zinc-400 text-[11px]">
                        <span>Tus fondos disponibles:</span>
                        <span className="font-mono">{formatCOP(totalFundsAvailable)} COP</span>
                      </div>
                    </div>

                    {canAfford ? (
                      <button
                        onClick={() => handlePurchase(lvl.id)}
                        className="w-full py-2.5 rounded-xl tok-gradient-red text-white font-bold text-xs tracking-wide shadow-lg hover:opacity-95 transition-all cursor-pointer"
                      >
                        {isThisActive ? 'Renovar Período' : 'Pagar con Saldo Disponible'} ({formatCOP(lvl.cost)} COP)
                      </button>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-[11px] text-rose-400">
                          Fondos insuficientes. Recarga tu cuenta subiendo tu comprobante de pago por QR.
                        </p>
                        <button
                          onClick={onOpenRecharge}
                          className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-zinc-700"
                        >
                          <ArrowDownLeft className="w-3.5 h-3.5" /> Ir a Recargar por QR
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    {isThisActive ? (
                      <div className="space-y-2">
                        <div className="w-full py-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-center font-bold text-xs text-emerald-300 flex items-center justify-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Nivel Activo ({status.daysRemaining} días)
                        </div>
                        {!lvl.isFree && (
                          <button
                            onClick={() => setPurchasingVipId(lvl.id)}
                            className="w-full py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white font-semibold text-[11px] transition-colors cursor-pointer flex items-center justify-center gap-1"
                          >
                            <RefreshCw className="w-3 h-3" /> Extender / Renovar Período
                          </button>
                        )}
                      </div>
                    ) : lvl.isFree ? (
                      <button
                        onClick={() => handlePurchase(lvl.id)}
                        className="w-full py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold text-xs transition-colors cursor-pointer"
                      >
                        Activar VIP 1 Gratuito
                      </button>
                    ) : (
                      <button
                        onClick={() => setPurchasingVipId(lvl.id)}
                        className="w-full py-3 rounded-xl tok-gradient-red text-white font-bold text-xs sm:text-sm tracking-wide shadow-lg hover:opacity-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer tok-glow-red"
                      >
                        Adquirir {lvl.name} ({formatCOP(lvl.cost)} COP) <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
